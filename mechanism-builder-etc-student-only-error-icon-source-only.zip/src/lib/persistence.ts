import type { Connector, PlacedPart } from '../data/model';

const STORAGE_NAMESPACE = 'mechanism-builder';
const SELECTED_TEMPLATE_KEY = `${STORAGE_NAMESPACE}:selected-template`;
const APP_MODE_KEY = `${STORAGE_NAMESPACE}:app-mode`;

export type AppMode = 'student' | 'dev';

export type PersistedAssignmentState = {
  current: number;
  answers: Record<string, unknown>;
  placedParts: PlacedPart[];
  connectors: Connector[];
  showAssignment: boolean;
  savedAt: string;
};

function getAssignmentStateKey(templateId: string) {
  return `${STORAGE_NAMESPACE}:state:${templateId}`;
}

export function loadSelectedTemplateId() {
  try {
    return window.localStorage.getItem(SELECTED_TEMPLATE_KEY);
  } catch {
    return null;
  }
}

export function saveSelectedTemplateId(templateId: string) {
  try {
    window.localStorage.setItem(SELECTED_TEMPLATE_KEY, templateId);
  } catch {
    // Ignore localStorage failures.
  }
}

export function loadAssignmentState(templateId: string): PersistedAssignmentState | null {
  try {
    const raw = window.localStorage.getItem(getAssignmentStateKey(templateId));
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return null;

    return {
      current: typeof parsed.current === 'number' ? parsed.current : 0,
      answers: parsed.answers && typeof parsed.answers === 'object' ? parsed.answers : {},
      placedParts: Array.isArray(parsed.placedParts) ? parsed.placedParts : [],
      connectors: Array.isArray(parsed.connectors) ? parsed.connectors : [],
      showAssignment: Boolean(parsed.showAssignment),
      savedAt: typeof parsed.savedAt === 'string' ? parsed.savedAt : '',
    };
  } catch {
    return null;
  }
}

export function saveAssignmentState(templateId: string, state: Omit<PersistedAssignmentState, 'savedAt'>) {
  try {
    const payload: PersistedAssignmentState = {
      ...state,
      savedAt: new Date().toISOString(),
    };
    window.localStorage.setItem(getAssignmentStateKey(templateId), JSON.stringify(payload));
    return payload.savedAt;
  } catch {
    return null;
  }
}

export function loadAppMode(): AppMode {
  try {
    const raw = window.localStorage.getItem(APP_MODE_KEY);
    return raw === 'dev' ? 'dev' : 'student';
  } catch {
    return 'student';
  }
}

export function saveAppMode(mode: AppMode) {
  try {
    window.localStorage.setItem(APP_MODE_KEY, mode);
  } catch {
    // Ignore localStorage failures.
  }
}
