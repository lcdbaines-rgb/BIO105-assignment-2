import { getPartDimensions } from '../data/model';
import type { Connector, FieldDef, PartDef, PlacedPart, PathwayTemplate, Zone } from '../data/model';

export function isFilled(field: FieldDef, value: unknown) {
  if (field.type === 'checkbox') return !!value;
  return typeof value === 'string' ? value.trim().length > 0 : !!value;
}

export function clamp(value: number, min: number, max: number) {
  return Math.max(min, Math.min(max, value));
}

export function getZoneY(zone: Zone, template: PathwayTemplate, part?: PartDef) {
  const dims = part ? getPartDimensions(part.kind) : { height: 82 };
  if (template.layoutMode === 'membrane') {
    if (zone === 'top') return 74;
    if (zone === 'membrane') {
      const membraneTop = 146;
      const membraneBottom = 226;
      const membraneCenter = (membraneTop + membraneBottom) / 2;
      return membraneCenter - dims.height / 2;
    }
    return 264;
  }

  if (zone === 'top') return 42;
  if (zone === 'left') return 220;
  if (zone === 'center') return 154;
  if (zone === 'right') return 110;
  return 250;
}

export function getZoneX(zone: Zone, template: PathwayTemplate, countInZone: number) {
  if (template.layoutMode === 'membrane') {
    const xBase = zone === 'top' ? 120 : zone === 'membrane' ? 170 : 190;
    return xBase + countInZone * 110;
  }
  const zoneBase: Record<string, number> = {
    top: 180,
    left: 130,
    center: 520,
    right: 940,
    bottom: 1180,
    membrane: 520,
  };
  return zoneBase[zone] + countInZone * 130;
}

export function createPlacedPart(part: PartDef, template: PathwayTemplate, countInZone = 0): PlacedPart {
  return {
    ...part,
    uid: `${part.id}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    x: getZoneX(part.defaultZone, template, countInZone),
    y: getZoneY(part.defaultZone, template, part),
    zone: part.defaultZone,
  };
}

type ExamplePlaced = { id: string; x: number; y: number; zone: Zone };
type ExampleConnector = { from: string; to: string; type: Connector['type']; curveOffset?: number };

function createPlacedFromExample(part: PartDef, example: ExamplePlaced): PlacedPart {
  return {
    ...part,
    uid: `${part.id}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    x: example.x,
    y: example.y,
    zone: example.zone,
  };
}

export function buildExampleModel(template: PathwayTemplate): { placedParts: PlacedPart[]; connectors: Connector[] } {
  const assignmentExampleModel = template.features?.exampleModelBuilder;
  if (assignmentExampleModel) {
    return assignmentExampleModel(template);
  }

  const examples: ExamplePlaced[] = [
    { id: 'temperature', x: 600, y: 24, zone: 'top' },
    { id: 'wheat-leaf', x: 90, y: 220, zone: 'left' },
    { id: 'urediniospore', x: 220, y: 170, zone: 'left' },
    { id: 'leaf-surface', x: 430, y: 158, zone: 'center' },
    { id: 'germ-tube', x: 610, y: 156, zone: 'center' },
    { id: 'stoma-entry', x: 790, y: 156, zone: 'center' },
    { id: 'haustorium', x: 970, y: 156, zone: 'center' },
    { id: 'uredinium', x: 1140, y: 156, zone: 'center' },
    { id: 'spore-release', x: 1310, y: 140, zone: 'right' },
    { id: 'wind', x: 1310, y: 42, zone: 'right' },
  ];
  const links: ExampleConnector[] = [
    { from: 'temperature', to: 'germ-tube', type: 'transition' },
    { from: 'wheat-leaf', to: 'leaf-surface', type: 'transition' },
    { from: 'urediniospore', to: 'leaf-surface', type: 'transition' },
    { from: 'leaf-surface', to: 'germ-tube', type: 'transition' },
    { from: 'germ-tube', to: 'stoma-entry', type: 'transition' },
    { from: 'stoma-entry', to: 'haustorium', type: 'transition' },
    { from: 'haustorium', to: 'uredinium', type: 'transition' },
    { from: 'uredinium', to: 'spore-release', type: 'transition' },
    { from: 'spore-release', to: 'wind', type: 'transition' },
  ];

  const partsById = new Map(template.parts.map((part) => [part.id, part]));
  const placedParts = examples.map((example) => createPlacedFromExample(partsById.get(example.id)!, example));
  const uidById = new Map(placedParts.map((part) => [part.id, part.uid]));
  const connectors = links.flatMap((link, index) => {
    const from = uidById.get(link.from);
    const to = uidById.get(link.to);
    const option = template.connectorOptions.find((item) => item.id === link.type);
    if (!from || !to || !option) return [];
    return [{ id: `example-${index + 1}`, from, to, type: link.type, label: option.short, color: option.color, curveOffset: link.curveOffset ?? 0 }];
  });
  return { placedParts, connectors };
}
