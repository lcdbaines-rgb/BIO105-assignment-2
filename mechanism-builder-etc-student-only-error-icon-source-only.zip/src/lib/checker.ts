import type { Connector, PathwayTemplate, PlacedPart } from '../data/model';
import { getPartHitboxDimensions } from '../data/model';
import { getSchemaForTemplate, type ActivatedPath, type BlockedPath, type CheckResult, type ConnectionRule, type PathwayRuleSchema } from '../data/rules';

function connectorKey(flowType: Connector['type'], from: string, to: string) {
  return `${flowType}:${from}->${to}`;
}

function findConnector(connectors: Connector[], placedByUid: Map<string, PlacedPart>, flowType: Connector['type'], fromId: string, toId: string) {
  return connectors.find((connector) => {
    if (connector.type !== flowType) return false;
    const fromPart = placedByUid.get(connector.from);
    const toPart = placedByUid.get(connector.to);
    return fromPart?.id === fromId && toPart?.id === toId;
  }) ?? null;
}

function zoneWarnings(schema: PathwayRuleSchema, placedParts: PlacedPart[]) {
  return placedParts.flatMap((part) => {
    const partRule = schema.parts.find((item) => item.id === part.id);
    if (!partRule) return [];
    return partRule.preferredZones.includes(part.zone) ? [] : [`${part.label} is in ${part.zone}, but it usually belongs in ${partRule.preferredZones.join(' or ')}.`];
  });
}

function labelForPart(schema: PathwayRuleSchema, partId: string) {
  return schema.parts.find((item) => item.id === partId)?.label ?? partId;
}

function formatSequence(schema: PathwayRuleSchema, sequence: string[]) {
  return sequence.map((partId) => labelForPart(schema, partId)).join(' → ');
}


function findPlacedPartsById(placedParts: PlacedPart[], partId: string) {
  return placedParts.filter((part) => part.id === partId);
}

function getHitboxRect(part: PlacedPart) {
  const hitbox = getPartHitboxDimensions(part.kind);
  return {
    left: part.x + hitbox.offsetX,
    top: part.y + hitbox.offsetY,
    right: part.x + hitbox.offsetX + hitbox.width,
    bottom: part.y + hitbox.offsetY + hitbox.height,
  };
}

function rectGap(a: ReturnType<typeof getHitboxRect>, b: ReturnType<typeof getHitboxRect>) {
  const dx = Math.max(0, a.left - b.right, b.left - a.right);
  const dy = Math.max(0, a.top - b.bottom, b.top - a.bottom);
  return Math.hypot(dx, dy);
}

function hasNearbyPart(placedParts: PlacedPart[], sourcePartId: string, nearbyPartId: string, maxGap: number) {
  const sourceParts = findPlacedPartsById(placedParts, sourcePartId);
  const nearbyParts = findPlacedPartsById(placedParts, nearbyPartId);
  if (!sourceParts.length || !nearbyParts.length) return false;

  return sourceParts.some((sourcePart) => {
    const sourceRect = getHitboxRect(sourcePart);
    return nearbyParts.some((nearbyPart) => rectGap(sourceRect, getHitboxRect(nearbyPart)) <= maxGap);
  });
}

function lifecycleCheck(placedParts: PlacedPart[], connectors: Connector[]): CheckResult {
  return {
    overallStatus: placedParts.length && connectors.length ? 'partial' : 'broken',
    activeConnectorIds: connectors.map((item) => item.id),
    blockedConnectorIds: [],
    activePartUids: placedParts.map((item) => item.uid),
    blockedPartUids: [],
    outputsProduced: [],
    outputsMissing: [],
    placementWarnings: [],
    activatedPaths: [],
    blockedPaths: [],
  };
}

function collectConnection(rule: ConnectionRule, connectionHit: Map<string, Connector | null>) {
  return connectionHit.get(connectorKey(rule.flowType, rule.sourcePartId, rule.targetPartId)) ?? null;
}

function registerConnectorAsActive(connector: Connector, placedByUid: Map<string, PlacedPart>, activeConnectorIds: Set<string>, activePartUids: Set<string>) {
  activeConnectorIds.add(connector.id);
  const from = placedByUid.get(connector.from);
  const to = placedByUid.get(connector.to);
  if (from) activePartUids.add(from.uid);
  if (to) activePartUids.add(to.uid);
}


function photosynthesisCheck(schema: PathwayRuleSchema, placedParts: PlacedPart[], connectors: Connector[]): CheckResult {
  const placedByUid = new Map(placedParts.map((part) => [part.uid, part]));
  const activeConnectorIds = new Set<string>();
  const blockedConnectorIds = new Set<string>();
  const activePartUids = new Set<string>();
  const blockedPartUids = new Set<string>();
  const outputsProduced = new Set<string>();
  const activatedPaths: ActivatedPath[] = [];
  const blockedPaths: BlockedPath[] = [];

  const connectionHit = new Map<string, Connector | null>();
  for (const rule of schema.requiredConnections) {
    const found = findConnector(connectors, placedByUid, rule.flowType, rule.sourcePartId, rule.targetPartId);
    connectionHit.set(connectorKey(rule.flowType, rule.sourcePartId, rule.targetPartId), found);
    if (found) registerConnectorAsActive(found, placedByUid, activeConnectorIds, activePartUids);
  }

  const consumePathRules = (pathId: string, flowType: Connector['type'], rules: ConnectionRule[], successReason: string, failureReason: string, failureBreakAt?: string, producedOutputs: string[] = []) => {
    const foundConnectors: Connector[] = [];
    const attemptedSequence = [rules[0].sourcePartId];
    let brokeAt = failureBreakAt;

    for (let index = 0; index < rules.length; index += 1) {
      const rule = rules[index];
      attemptedSequence.push(rule.targetPartId);
      const hit = collectConnection(rule, connectionHit);
      if (!hit) {
        brokeAt = index === rules.length - 1 && failureBreakAt ? failureBreakAt : rule.sourcePartId;
        blockedPaths.push({
          id: `${pathId}-blocked`,
          flowType,
          attemptedSequence: [...attemptedSequence],
          connectorIds: foundConnectors.map((item) => item.id),
          brokeAt,
          reason: failureReason,
        });
        return false;
      }
      foundConnectors.push(hit);
    }

    foundConnectors.forEach((connector) => registerConnectorAsActive(connector, placedByUid, activeConnectorIds, activePartUids));
    producedOutputs.forEach((output) => outputsProduced.add(output));
    activatedPaths.push({
      id: pathId,
      flowType,
      sequence: [rules[0].sourcePartId, ...rules.map((rule) => rule.targetPartId)],
      connectorIds: foundConnectors.map((item) => item.id),
      description: successReason,
    });
    return true;
  };

  const lightChainRules = [
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'light-psii' && rule.targetPartId === 'photosystem-ii' && rule.flowType === 'transition')!,
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'photosystem-ii' && rule.targetPartId === 'water-oxygen' && rule.flowType === 'transition')!,
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'photosystem-ii' && rule.targetPartId === 'plastoquinone' && rule.flowType === 'electronFlow')!,
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'plastoquinone' && rule.targetPartId === 'cytochrome-b6f' && rule.flowType === 'electronFlow')!,
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'cytochrome-b6f' && rule.targetPartId === 'plastocyanin' && rule.flowType === 'electronFlow')!,
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'plastocyanin' && rule.targetPartId === 'photosystem-i' && rule.flowType === 'electronFlow')!,
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'light-psi' && rule.targetPartId === 'photosystem-i' && rule.flowType === 'transition')!,
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'photosystem-i' && rule.targetPartId === 'nadph-output' && rule.flowType === 'electronFlow')!,
  ];

  const lightChainGood = consumePathRules(
    'light-reactions',
    'electronFlow',
    lightChainRules,
    'Light energy drives electrons from Photosystem II through Photosystem I, releasing oxygen and reducing NADP⁺ to NADPH.',
    'The light-reaction electron chain is incomplete.',
    'photosystem-i',
    ['oxygen', 'nadph'],
  );

  const protonPumpRules = [
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'low-protons' && rule.targetPartId === 'cytochrome-b6f' && rule.flowType === 'protonFlow')!,
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'cytochrome-b6f' && rule.targetPartId === 'protons' && rule.flowType === 'protonFlow')!,
  ];
  const protonPumpGood = consumePathRules(
    'cytochrome-b6f-pump',
    'protonFlow',
    protonPumpRules,
    'Cytochrome b6f contributes to proton accumulation in the thylakoid lumen.',
    'Cytochrome b6f is missing part of its proton-pumping path.',
    'cytochrome-b6f',
  );

  const atpRules = [
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'protons' && rule.targetPartId === 'atp-synthase' && rule.flowType === 'protonFlow')!,
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'atp-synthase' && rule.targetPartId === 'low-protons' && rule.flowType === 'protonFlow')!,
  ];
  const atpTransitionRule = schema.requiredConnections.find((rule) => rule.sourcePartId === 'atp-synthase' && rule.targetPartId === 'adppi' && rule.flowType === 'transition')!;
  if (protonPumpGood) {
    const protonReturnOk = consumePathRules(
      'atp-branch',
      'protonFlow',
      atpRules,
      'Protons return through ATP synthase from the lumen to the stroma.',
      'ATP synthase proton return is incomplete.',
      'atp-synthase',
    );
    if (protonReturnOk) {
      const atpTransition = collectConnection(atpTransitionRule, connectionHit);
      const adpPiNearby = hasNearbyPart(placedParts, 'atp-synthase', 'adppi', 72);
      if (atpTransition) registerConnectorAsActive(atpTransition, placedByUid, activeConnectorIds, activePartUids);
      if (atpTransition || adpPiNearby) {
        outputsProduced.add('atp');
        activatedPaths.push({
          id: 'atp-output',
          flowType: 'protonFlow',
          sequence: ['protons', 'atp-synthase', 'low-protons', 'adppi'],
          connectorIds: [
            collectConnection(atpRules[0], connectionHit)?.id,
            collectConnection(atpRules[1], connectionHit)?.id,
            atpTransition?.id,
          ].filter(Boolean) as string[],
          description: atpTransition ? 'ATP synthase uses proton return to drive the ADP + Pi → ATP step.' : 'ATP synthase is positioned to support ATP production when ADP + Pi is placed nearby.',
        });
      } else {
        blockedPaths.push({
          id: 'atp-output-blocked',
          flowType: 'protonFlow',
          attemptedSequence: ['protons', 'atp-synthase', 'low-protons', 'adppi'],
          connectorIds: [
            collectConnection(atpRules[0], connectionHit)?.id,
            collectConnection(atpRules[1], connectionHit)?.id,
          ].filter(Boolean) as string[],
          brokeAt: 'atp-synthase',
          reason: 'ATP output is broken because the ADP + Pi → ATP icon is not placed near ATP synthase.',
        });
      }
    }
  }

  const allowedConnectionKeys = new Set(schema.requiredConnections.map((rule) => connectorKey(rule.flowType, rule.sourcePartId, rule.targetPartId)));
  for (const connector of connectors) {
    if (activeConnectorIds.has(connector.id)) continue;
    const from = placedByUid.get(connector.from);
    const to = placedByUid.get(connector.to);
    if (!from || !to) continue;
    blockedConnectorIds.add(connector.id);
    blockedPartUids.add(from.uid);
    blockedPartUids.add(to.uid);
    const key = connectorKey(connector.type, from.id, to.id);
    if (!allowedConnectionKeys.has(key)) {
      blockedPaths.push({
        id: `invalid-${connector.id}`,
        flowType: connector.type,
        attemptedSequence: [from.id, to.id],
        connectorIds: [connector.id],
        brokeAt: from.id,
        reason: `${labelForPart(schema, from.id)} should not connect directly to ${labelForPart(schema, to.id)} with ${connector.type === 'electronFlow' ? 'electron flow' : connector.type === 'protonFlow' ? 'proton flow' : 'a light/output arrow'} here.`,
      });
    }
  }

  const placementWarnings = zoneWarnings(schema, placedParts);
  const expectedOutputs = ['oxygen', 'nadph', 'atp'];
  const outputsMissing = expectedOutputs.filter((output) => !outputsProduced.has(output));
  let overallStatus: CheckResult['overallStatus'] = 'broken';
  if (outputsProduced.size === expectedOutputs.length && placementWarnings.length === 0 && blockedPaths.length === 0 && blockedConnectorIds.size === 0) overallStatus = 'success';
  else if (outputsProduced.size > 0 || activeConnectorIds.size > 0 || blockedConnectorIds.size > 0) overallStatus = 'partial';

  return {
    overallStatus,
    activeConnectorIds: [...activeConnectorIds],
    blockedConnectorIds: [...blockedConnectorIds],
    activePartUids: [...activePartUids],
    blockedPartUids: [...blockedPartUids],
    outputsProduced: [...outputsProduced],
    outputsMissing,
    placementWarnings,
    activatedPaths: activatedPaths.map((path) => ({ ...path, description: `${path.description} (${formatSequence(schema, path.sequence)})` })),
    blockedPaths: blockedPaths.map((path) => ({ ...path, reason: `${path.reason} (${formatSequence(schema, path.attemptedSequence)})` })),
  };
}

export function evaluateModel(template: PathwayTemplate, placedParts: PlacedPart[], connectors: Connector[]): CheckResult {
  const schema = getSchemaForTemplate(template);
  const checkerStyle = template.features?.checkerStyle ?? (schema ? 'mitochondria' : 'lifecycle');
  if (!schema || checkerStyle === 'lifecycle') return lifecycleCheck(placedParts, connectors);
  if (checkerStyle === 'photosynthesis') return photosynthesisCheck(schema, placedParts, connectors);
  const normalOnlyMode = template.features?.normalOnlyMode ?? !template.screens.some((screen) => screen.id === 'ucp3');

  const placedByUid = new Map(placedParts.map((part) => [part.uid, part]));
  const activeConnectorIds = new Set<string>();
  const blockedConnectorIds = new Set<string>();
  const activePartUids = new Set<string>();
  const blockedPartUids = new Set<string>();
  const outputsProduced = new Set<string>();
  const activatedPaths: ActivatedPath[] = [];
  const blockedPaths: BlockedPath[] = [];

  const connectionHit = new Map<string, Connector | null>();
  for (const rule of schema.requiredConnections) {
    const found = findConnector(connectors, placedByUid, rule.flowType, rule.sourcePartId, rule.targetPartId);
    connectionHit.set(connectorKey(rule.flowType, rule.sourcePartId, rule.targetPartId), found);
    if (found) registerConnectorAsActive(found, placedByUid, activeConnectorIds, activePartUids);
  }

  const consumePathRules = (pathId: string, flowType: Connector['type'], rules: ConnectionRule[], successReason: string, failureReason: string, failureBreakAt?: string, producedOutputs: string[] = []) => {
    const foundConnectors: Connector[] = [];
    const attemptedSequence = [rules[0].sourcePartId];
    let brokeAt = failureBreakAt;

    for (let index = 0; index < rules.length; index += 1) {
      const rule = rules[index];
      attemptedSequence.push(rule.targetPartId);
      const hit = collectConnection(rule, connectionHit);
      if (!hit) {
        brokeAt = index === rules.length - 1 && failureBreakAt ? failureBreakAt : rule.sourcePartId;
        blockedPaths.push({
          id: `${pathId}-blocked`,
          flowType,
          attemptedSequence: [...attemptedSequence],
          connectorIds: foundConnectors.map((item) => item.id),
          brokeAt,
          reason: failureReason,
        });
        return false;
      }
      foundConnectors.push(hit);
    }

    foundConnectors.forEach((connector) => registerConnectorAsActive(connector, placedByUid, activeConnectorIds, activePartUids));
    producedOutputs.forEach((output) => outputsProduced.add(output));
    activatedPaths.push({
      id: pathId,
      flowType,
      sequence: [rules[0].sourcePartId, ...rules.map((rule) => rule.targetPartId)],
      connectorIds: foundConnectors.map((item) => item.id),
      description: successReason,
    });
    return true;
  };

  const electronRules = [
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'nadh' && rule.targetPartId === 'complex-i' && rule.flowType === 'electronFlow')!,
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'complex-i' && rule.targetPartId === 'complex-ii-q' && rule.flowType === 'electronFlow')!,
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'complex-ii-q' && rule.targetPartId === 'complex-iii' && rule.flowType === 'electronFlow')!,
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'complex-iii' && rule.targetPartId === 'cytochrome-c' && rule.flowType === 'electronFlow')!,
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'cytochrome-c' && rule.targetPartId === 'complex-iv' && rule.flowType === 'electronFlow')!,
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'complex-iv' && rule.targetPartId === 'oxygen-water' && rule.flowType === 'electronFlow')!,
  ];
  const mainChainGood = consumePathRules(
    'electron-chain',
    'electronFlow',
    electronRules,
    'Electrons reach oxygen after Complex IV, producing water and oxidizing NADH.',
    'Electron flow breaks before oxygen is reduced to water.',
    'oxygen-water',
    ['nad-plus', 'water'],
  );

  const fadRules = [
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'fadh2' && rule.targetPartId === 'complex-ii-q' && rule.flowType === 'electronFlow')!,
  ];
  consumePathRules(
    'fadh2-entry',
    'electronFlow',
    fadRules,
    'FADH₂ donates electrons into Complex II + Q and is shown as FAD.',
    'FADH₂ entry is incomplete, so the Complex II + Q branch is not fully shown.',
    'complex-ii-q',
    ['fad'],
  );

  const pumpPairs = [
    {
      id: 'pump-complex-i',
      complexId: 'complex-i',
      inRule: schema.requiredConnections.find((rule) => rule.sourcePartId === 'low-protons' && rule.targetPartId === 'complex-i' && rule.flowType === 'protonFlow')!,
      outRule: schema.requiredConnections.find((rule) => rule.sourcePartId === 'complex-i' && rule.targetPartId === 'protons' && rule.flowType === 'protonFlow')!,
      label: 'Complex I pumps protons from the matrix side into the intermembrane space.',
    },
    {
      id: 'pump-complex-iii',
      complexId: 'complex-iii',
      inRule: schema.requiredConnections.find((rule) => rule.sourcePartId === 'low-protons' && rule.targetPartId === 'complex-iii' && rule.flowType === 'protonFlow')!,
      outRule: schema.requiredConnections.find((rule) => rule.sourcePartId === 'complex-iii' && rule.targetPartId === 'protons' && rule.flowType === 'protonFlow')!,
      label: 'Complex III pumps protons from the matrix side into the intermembrane space.',
    },
    {
      id: 'pump-complex-iv',
      complexId: 'complex-iv',
      inRule: schema.requiredConnections.find((rule) => rule.sourcePartId === 'low-protons' && rule.targetPartId === 'complex-iv' && rule.flowType === 'protonFlow')!,
      outRule: schema.requiredConnections.find((rule) => rule.sourcePartId === 'complex-iv' && rule.targetPartId === 'protons' && rule.flowType === 'protonFlow')!,
      label: 'Complex IV pumps protons from the matrix side into the intermembrane space.',
    },
  ];
  let protonPumpsGood = mainChainGood;
  for (const pump of pumpPairs) {
    const ok = consumePathRules(
      pump.id,
      'protonFlow',
      [pump.inRule, pump.outRule],
      pump.label,
      `${labelForPart(schema, pump.complexId)} is missing part of its proton-pumping path.`,
      pump.complexId,
    );
    protonPumpsGood = protonPumpsGood && ok;
  }

  const atpRules = [
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'protons' && rule.targetPartId === 'atp-synthase' && rule.flowType === 'protonFlow')!,
    schema.requiredConnections.find((rule) => rule.sourcePartId === 'atp-synthase' && rule.targetPartId === 'low-protons' && rule.flowType === 'protonFlow')!,
  ];
  const atpTransitionRule = schema.requiredConnections.find((rule) => rule.sourcePartId === 'atp-synthase' && rule.targetPartId === 'adppi' && rule.flowType === 'transition')!;
  if (protonPumpsGood) {
    const protonReturnOk = consumePathRules(
      'atp-branch',
      'protonFlow',
      atpRules,
      'Protons return through ATP synthase from high H⁺ to low H⁺.',
      'ATP output is broken because proton return through ATP synthase is incomplete.',
      'atp-synthase',
    );

    if (protonReturnOk) {
      const atpTransition = collectConnection(atpTransitionRule, connectionHit);
      const adpPiNearby = hasNearbyPart(placedParts, 'atp-synthase', 'adppi', 72);

      if (atpTransition) {
        registerConnectorAsActive(atpTransition, placedByUid, activeConnectorIds, activePartUids);
      }

      if (adpPiNearby || atpTransition) {
        outputsProduced.add('atp');
        activatedPaths.push({
          id: 'atp-output',
          flowType: 'protonFlow',
          sequence: ['protons', 'atp-synthase', 'low-protons', 'adppi'],
          connectorIds: [
            collectConnection(atpRules[0], connectionHit)?.id,
            collectConnection(atpRules[1], connectionHit)?.id,
            atpTransition?.id,
          ].filter(Boolean) as string[],
          description: atpTransition
            ? 'ATP synthase uses proton return to drive the ADP + Pi → ATP step.'
            : 'ATP synthase uses proton return to drive ATP production when the ADP + Pi → ATP icon is placed nearby.',
        });
      } else {
        blockedPaths.push({
          id: 'atp-output-blocked',
          flowType: 'protonFlow',
          attemptedSequence: ['protons', 'atp-synthase', 'low-protons', 'adppi'],
          connectorIds: [
            collectConnection(atpRules[0], connectionHit)?.id,
            collectConnection(atpRules[1], connectionHit)?.id,
          ].filter(Boolean) as string[],
          brokeAt: 'atp-synthase',
          reason: 'ATP output is broken because the ADP + Pi → ATP icon is not placed near ATP synthase.',
        });
      }
    }
  }

  if (!normalOnlyMode) {
    const heatRules = [
      schema.requiredConnections.find((rule) => rule.sourcePartId === 'protons' && rule.targetPartId === 'ucp3' && rule.flowType === 'protonFlow')!,
      schema.requiredConnections.find((rule) => rule.sourcePartId === 'ucp3' && rule.targetPartId === 'low-protons' && rule.flowType === 'protonFlow')!,
      schema.requiredConnections.find((rule) => rule.sourcePartId === 'mdma' && rule.targetPartId === 'ucp3' && rule.flowType === 'transition')!,
    ];
    if (protonPumpsGood) {
      const protonIn = collectConnection(heatRules[0], connectionHit);
      const protonOut = collectConnection(heatRules[1], connectionHit);
      const mdmaGate = collectConnection(heatRules[2], connectionHit);
      if (protonIn && protonOut && mdmaGate) {
        [protonIn, protonOut, mdmaGate].forEach((connector) => registerConnectorAsActive(connector, placedByUid, activeConnectorIds, activePartUids));
        outputsProduced.add('heat');
        activatedPaths.push({
          id: 'heat-branch',
          flowType: 'protonFlow',
          sequence: ['protons', 'ucp3', 'low-protons', 'heat'],
          connectorIds: [protonIn.id, protonOut.id, mdmaGate.id],
          description: 'MDMA gates UCP3, allowing protons to leak from high H⁺ to low H⁺ and dissipate the gradient as heat.',
        });
      } else {
        blockedPaths.push({
          id: 'heat-branch-blocked',
          flowType: 'mixed',
          attemptedSequence: ['protons', 'ucp3', 'low-protons', 'heat'],
          connectorIds: [protonIn?.id, protonOut?.id, mdmaGate?.id].filter(Boolean) as string[],
          brokeAt: !protonIn ? 'protons' : !protonOut ? 'ucp3' : 'low-protons',
          reason: 'The MDMA/UCP3 heat branch is incomplete.',
        });
      }
    }
  }

  const allowedConnectionKeys = new Set(
    schema.requiredConnections.map((rule) => connectorKey(rule.flowType, rule.sourcePartId, rule.targetPartId))
  );

  for (const connector of connectors) {
    if (activeConnectorIds.has(connector.id)) continue;
    const from = placedByUid.get(connector.from);
    const to = placedByUid.get(connector.to);
    if (!from || !to) continue;
    blockedConnectorIds.add(connector.id);
    blockedPartUids.add(from.uid);
    blockedPartUids.add(to.uid);

    const key = connectorKey(connector.type, from.id, to.id);
    if (!allowedConnectionKeys.has(key)) {
      blockedPaths.push({
        id: `invalid-${connector.id}`,
        flowType: connector.type,
        attemptedSequence: [from.id, to.id],
        connectorIds: [connector.id],
        brokeAt: from.id,
        reason: `${labelForPart(schema, from.id)} should not connect directly to ${labelForPart(schema, to.id)} with ${connector.type === 'electronFlow' ? 'electron flow' : connector.type === 'protonFlow' ? 'proton flow' : 'an output/signal'} here.`,
      });
    }
  }

  const placementWarnings = zoneWarnings(schema, placedParts);
  const expectedOutputs = normalOnlyMode ? ['atp', 'nad-plus', 'fad', 'water'] : ['atp', 'heat', 'nad-plus', 'fad', 'water'];
  const outputsMissing = expectedOutputs.filter((output) => !outputsProduced.has(output));

  let overallStatus: CheckResult['overallStatus'] = 'broken';
  if (outputsProduced.size === expectedOutputs.length && placementWarnings.length === 0 && blockedPaths.length === 0 && blockedConnectorIds.size === 0) overallStatus = 'success';
  else if (outputsProduced.size > 0 || activeConnectorIds.size > 0 || blockedConnectorIds.size > 0) overallStatus = 'partial';

  return {
    overallStatus,
    activeConnectorIds: [...activeConnectorIds],
    blockedConnectorIds: [...blockedConnectorIds],
    activePartUids: [...activePartUids],
    blockedPartUids: [...blockedPartUids],
    outputsProduced: [...outputsProduced],
    outputsMissing,
    placementWarnings,
    activatedPaths: activatedPaths.map((path) => ({
      ...path,
      description: `${path.description} (${formatSequence(schema, path.sequence)})`,
    })),
    blockedPaths: blockedPaths.map((path) => ({
      ...path,
      reason: `${path.reason} (${formatSequence(schema, path.attemptedSequence)})`,
    })),
  };
}
