import { useEffect, useMemo, useRef, useState } from 'react';
import { buildExampleModel, clamp, createPlacedPart } from '../lib/utils';
import { evaluateModel } from '../lib/checker';
import type { CheckResult } from '../data/rules';
import { Button } from './UI';
import { PaletteToken } from './PaletteToken';
import { PartGraphic } from './PartGraphic';
import { getPartDimensions, getPartHitboxDimensions, PART_HEIGHT, PART_WIDTH, type Connector, type ConnectorType, type DragState, type PathwayTemplate, type PlacedPart, type Pointer, type Zone } from '../data/model';
import type { AnchorPointDef } from '../assignments/types';

function FlowParticle({
  connectorId,
  pathD,
  durationSeconds,
  iconSize,
  renderIcon,
  maxDelayMs = 500,
  endPadding = 0,
}: {
  connectorId: string;
  pathD: string;
  durationSeconds: number;
  iconSize: number;
  renderIcon: (id: string) => any;
  maxDelayMs?: number;
  endPadding?: number;
}) {
  const pathRef = useRef<SVGPathElement | null>(null);
  const frameRef = useRef<number | null>(null);
  const runStartRef = useRef<number | null>(null);
  const delayRef = useRef(Math.random() * maxDelayMs);
  const [position, setPosition] = useState<{ x: number; y: number } | null>(null);

  useEffect(() => {
    let mounted = true;
    runStartRef.current = null;
    delayRef.current = Math.random() * maxDelayMs;
    setPosition(null);

    const step = (now: number) => {
      const path = pathRef.current;
      if (!mounted || !path) {
        frameRef.current = window.requestAnimationFrame(step);
        return;
      }

      if (runStartRef.current === null) {
        runStartRef.current = now + delayRef.current;
      }

      const runStart = runStartRef.current;
      if (now < runStart) {
        setPosition(null);
        frameRef.current = window.requestAnimationFrame(step);
        return;
      }

      const elapsed = now - runStart;
      const progress = elapsed / (durationSeconds * 1000);

      if (progress >= 1) {
        runStartRef.current = now + Math.random() * maxDelayMs;
        setPosition(null);
        frameRef.current = window.requestAnimationFrame(step);
        return;
      }

      const pathLength = path.getTotalLength();
      const usableLength = Math.max(0, pathLength - endPadding);
      const point = path.getPointAtLength(usableLength * progress);
      setPosition({ x: point.x, y: point.y });
      frameRef.current = window.requestAnimationFrame(step);
    };

    frameRef.current = window.requestAnimationFrame(step);

    return () => {
      mounted = false;
      if (frameRef.current !== null) window.cancelAnimationFrame(frameRef.current);
    };
  }, [connectorId, durationSeconds, pathD, maxDelayMs, endPadding]);

  return (
    <>
      <path ref={pathRef} d={pathD} fill="none" stroke="none" pointerEvents="none" />
      {position ? (
        <g transform={`translate(${position.x - iconSize / 2}, ${position.y - iconSize / 2})`} opacity="0.96" pointerEvents="none">
          {renderIcon(`movingParticle-${connectorId}`)}
        </g>
      ) : null}
    </>
  );
}


export function ModelCanvas({
  canvasCaptureRef,
  template,
  placedParts,
  setPlacedParts,
  currentScreenId,
  connectors,
  setConnectors,
  setAnswers,
}: {
  canvasCaptureRef?: React.MutableRefObject<HTMLDivElement | null>;
  template: PathwayTemplate;
  placedParts: PlacedPart[];
  setPlacedParts: React.Dispatch<React.SetStateAction<PlacedPart[]>>;
  currentScreenId: string;
  connectors: Connector[];
  setConnectors: React.Dispatch<React.SetStateAction<Connector[]>>;
  setAnswers: React.Dispatch<React.SetStateAction<Record<string, unknown>>>;
}) {
  const canvasRef = useRef<HTMLDivElement | null>(null);
  const dragRef = useRef<DragState | null>(null);
  const [draggingUid, setDraggingUid] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [selectedConnectorId, setSelectedConnectorId] = useState<string | null>(null);
  const [interactionMode, setInteractionMode] = useState<'move' | 'connect'>('move');
  const [pendingStart, setPendingStart] = useState<string | null>(null);
  const [selectedConnectorType, setSelectedConnectorType] = useState<ConnectorType>(template.connectorOptions[0]?.id ?? 'transition');
  const [pointerPos, setPointerPos] = useState<Pointer | null>(null);
  const [hoveredPartUid, setHoveredPartUid] = useState<string | null>(null);
  const [snappedTarget, setSnappedTarget] = useState<{ uid: string; anchor: { name: string; x: number; y: number } } | null>(null);
  const connectorDragRef = useRef<{ id: string; startY: number; startOffset: number } | null>(null);
  const [checkResult, setCheckResult] = useState<CheckResult | null>(null);
  const [playbackActiveConnectorIds, setPlaybackActiveConnectorIds] = useState<string[]>([]);
  const [playbackBlockedConnectorIds, setPlaybackBlockedConnectorIds] = useState<string[]>([]);
  const [playbackActivePartUids, setPlaybackActivePartUids] = useState<string[]>([]);
  const [playbackBlockedPartUids, setPlaybackBlockedPartUids] = useState<string[]>([]);
  const [breakMarkers, setBreakMarkers] = useState<Array<{ x: number; y: number }>>([]);
  const playbackTimersRef = useRef<number[]>([]);

  const clearPlayback = () => {
    playbackTimersRef.current.forEach((timerId) => window.clearTimeout(timerId));
    playbackTimersRef.current = [];
    setPlaybackActiveConnectorIds([]);
    setPlaybackBlockedConnectorIds([]);
    setPlaybackActivePartUids([]);
    setPlaybackBlockedPartUids([]);
    setBreakMarkers([]);
  };

  useEffect(() => {
    setSelectedConnectorType(template.connectorOptions[0]?.id ?? 'transition');
    setPendingStart(null);
    setPointerPos(null);
    setHoveredPartUid(null);
    setSnappedTarget(null);
    setCheckResult(null);
    setSelectedId(null);
    setSelectedConnectorId(null);
    clearPlayback();
  }, [template.id]);

  useEffect(() => {
    setCheckResult(null);
    clearPlayback();
  }, [placedParts, connectors]);

  useEffect(() => () => {
    playbackTimersRef.current.forEach((timerId) => window.clearTimeout(timerId));
  }, []);

  const currentPrompt = template.promptByScreen[currentScreenId] || 'Build the model by placing parts and connecting them with arrows.';

  const getPart = (uid: string | null) => {
    if (!uid) return null;
    return placedParts.find((item) => item.uid === uid) ?? null;
  };

  const getCenter = (uid: string) => {
    const part = getPart(uid);
    if (!part) return null;
    const dims = getPartDimensions(part.kind);
    return { x: part.x + dims.width / 2, y: part.y + dims.height / 2 };
  };

  const isMembraneProteinKind = (kind: PlacedPart['kind']) => ['complexI', 'complexII', 'complexIIQ', 'complexIII', 'complexIV', 'atpSynthase', 'ucp'].includes(kind);

  const getPartBounds = (uid: string) => {
    const part = getPart(uid);
    if (!part) return null;
    const dims = getPartDimensions(part.kind);
    const hitbox = getPartHitboxDimensions(part.kind);
    const shapeLeft = part.x + hitbox.offsetX;
    const shapeTop = part.y + hitbox.offsetY;
    const shapeWidth = hitbox.width;
    const shapeHeight = hitbox.height;
    return {
      part,
      dims,
      hitbox,
      shapeLeft,
      shapeTop,
      shapeWidth,
      shapeHeight,
      centerX: shapeLeft + shapeWidth / 2,
      centerY: shapeTop + shapeHeight / 2,
    };
  };

  const toAbsoluteAnchor = (uid: string, relX: number, relY: number, name: string) => {
    const bounds = getPartBounds(uid);
    if (!bounds) return null;
    return {
      name,
      x: bounds.part.x + bounds.dims.width * relX,
      y: bounds.part.y + bounds.dims.height * relY,
    };
  };

  const isInputAnchor = (name: string) => /in$/i.test(name);
  const isOutputAnchor = (name: string) => /out$/i.test(name);
  const protonRoleAliases: Record<string, string[]> = {
    protonTopPump: ['protonOut'],
    protonBottomExit: ['protonOut'],
    protonBottomPool: ['protonOut'],
    protonBottomIntake: ['protonIn'],
    protonTopIntake: ['protonIn'],
    protonTopPool: ['protonIn'],
  };
  const protonAnchorNames = ['protonTopPump', 'protonBottomIntake', 'protonTopIntake', 'protonBottomExit', 'protonTopPool', 'protonBottomPool', 'protonIn', 'protonOut'];
  const getPreferredTargetAnchors = (fromAnchorName: string | undefined, flowType: ConnectorType) => {
    if (!fromAnchorName) return null;
    if (flowType === 'electronFlow') {
      if (/oxygenOut/i.test(fromAnchorName)) return ['electronIn', 'transitionIn'];
      if (isOutputAnchor(fromAnchorName)) return ['electronIn', 'transitionIn'];
      if (isInputAnchor(fromAnchorName)) return ['electronOut', 'oxygenOut', 'atpOut', 'transitionOut'];
      return ['electronIn'];
    }
    if (flowType === 'protonFlow') {
      if (fromAnchorName === 'protonBottomPool') return ['protonBottomIntake'];
      if (fromAnchorName === 'protonTopPump') return ['protonTopPool'];
      if (fromAnchorName === 'protonTopPool') return ['protonTopIntake'];
      if (fromAnchorName === 'protonBottomExit') return ['protonBottomPool'];
      if (fromAnchorName === 'protonIn' || fromAnchorName === 'protonTopIntake' || fromAnchorName === 'protonBottomIntake') return ['protonTopPump', 'protonBottomExit', 'protonBottomPool', 'protonOut'];
      if (fromAnchorName === 'protonOut') return ['protonTopPool', 'protonTopIntake', 'protonBottomIntake', 'protonIn'];
      return protonAnchorNames;
    }
    if (isOutputAnchor(fromAnchorName)) return ['transitionIn'];
    if (isInputAnchor(fromAnchorName)) return ['transitionOut', 'atpOut'];
    return ['transitionIn', 'transitionOut', 'atpOut'];
  };

  const filterAnchorsByNames = (anchors: Array<{ name: string; x: number; y: number }>, allowedNames: string[] | null | undefined) => {
    if (!allowedNames || !allowedNames.length) return anchors;
    const allowed = anchors.filter((anchor) => allowedNames.includes(anchor.name));
    return allowed.length ? allowed : anchors;
  };

  const getCandidateAnchors = (uid: string, flowType: ConnectorType) => {
    const bounds = getPartBounds(uid);
    if (!bounds) return [];
    const { part, dims, shapeLeft, shapeTop, shapeWidth, shapeHeight, centerX, centerY } = bounds;
    const markerBackoff = flowType === 'protonFlow' ? 10 : flowType === 'electronFlow' ? 7 : 4;
    const edgeInsetX = Math.max(4, Math.min(shapeWidth * 0.08, 8));
    const edgeInsetY = Math.max(4, Math.min(shapeHeight * 0.08, 8));
    const genericAnchors = [
      { name: 'top', x: centerX, y: shapeTop + edgeInsetY + markerBackoff },
      { name: 'bottom', x: centerX, y: shapeTop + shapeHeight - edgeInsetY - markerBackoff },
      { name: 'left', x: shapeLeft + edgeInsetX + markerBackoff, y: centerY },
      { name: 'right', x: shapeLeft + shapeWidth - edgeInsetX - markerBackoff, y: centerY },
    ];

    if (template.features?.anchorSet !== 'assignment') return genericAnchors;

    const configured = (template.features.customAnchors?.[part.id]?.[flowType] ?? [])
      .map((anchor: AnchorPointDef) => toAbsoluteAnchor(uid, anchor.x, anchor.y, anchor.name))
      .filter((anchor): anchor is { name: string; x: number; y: number } => Boolean(anchor));

    return (configured && configured.length ? configured : genericAnchors) as Array<{ name: string; x: number; y: number }>;
  };

  const pickBestAnchor = (
    anchors: Array<{ name: string; x: number; y: number }>,
    role: 'from' | 'to',
    flowType: ConnectorType,
    counterpartPoint?: { x: number; y: number } | null,
  ) => {
    if (!anchors.length) return null;
    if (!counterpartPoint) {
      if (role === 'from') {
        return anchors[anchors.length - 1] ?? anchors[0];
      }
      return anchors[0];
    }
    return anchors
      .map((anchor) => {
        const dx = counterpartPoint.x - anchor.x;
        const dy = counterpartPoint.y - anchor.y;
        const directionalBias = role === 'from'
          ? (flowType === 'protonFlow' ? Math.abs(dx) * 0.12 + Math.max(0, dy) * 0.3 : Math.max(0, dx) * 0.3)
          : (flowType === 'protonFlow' ? Math.abs(dx) * 0.12 + Math.max(0, -dy) * 0.3 : Math.max(0, -dx) * 0.3);
        return {
          anchor,
          score: Math.hypot(dx, dy) - directionalBias,
        };
      })
      .sort((a, b) => a.score - b.score)[0]?.anchor ?? anchors[0];
  };

  const getConnectorAnchor = (
    uid: string,
    role: 'from' | 'to',
    flowType: ConnectorType,
    counterpartId?: string | null,
    preferredAnchorName?: string,
    counterpartAnchorName?: string,
  ) => {
    const anchors = getCandidateAnchors(uid, flowType);
    if (preferredAnchorName) {
      const exact = anchors.find((anchor) => anchor.name === preferredAnchorName);
      if (exact) return exact;
      if (flowType === 'protonFlow' && protonRoleAliases[preferredAnchorName]) {
        const alias = anchors.find((anchor) => protonRoleAliases[preferredAnchorName].includes(anchor.name));
        if (alias) return alias;
      }
    }
    const counterpartBounds = counterpartId ? getPartBounds(counterpartId) : null;
    const counterpartPoint = counterpartBounds ? { x: counterpartBounds.centerX, y: counterpartBounds.centerY } : null;
    const preferredNames = role === 'to' ? getPreferredTargetAnchors(counterpartAnchorName, flowType) : null;
    return pickBestAnchor(filterAnchorsByNames(anchors, preferredNames), role, flowType, counterpartPoint);
  };

  const getSnappedConnectionTarget = (pointer: Pointer, fromUid: string, flowType: ConnectorType): { uid: string; anchor: { name: string; x: number; y: number }; distance: number } | null => {
    const SNAP_RADIUS = 34;
    let best: { uid: string; anchor: { name: string; x: number; y: number }; distance: number } | null = null;
    const fromAnchor = getConnectorAnchor(fromUid, 'from', flowType);
    const preferredTargetNames = getPreferredTargetAnchors(fromAnchor?.name, flowType);
    placedParts.forEach((part) => {
      if (part.uid === fromUid) return;
      filterAnchorsByNames(getCandidateAnchors(part.uid, flowType), preferredTargetNames).forEach((anchor) => {
        const distance = Math.hypot(anchor.x - pointer.x, anchor.y - pointer.y);
        if (distance <= SNAP_RADIUS && (!best || distance < best.distance)) {
          best = { uid: part.uid, anchor, distance };
        }
      });
    });
    return best;
  };



  const isProtonPoolPart = (part: PlacedPart | null) => !!part && (part.id === 'protons' || part.id === 'low-protons');

  const getVisualContactOffset = (part: PlacedPart | null, anchorName: string | undefined, flowType: ConnectorType, role: 'from' | 'to') => {
    if (!part) return 0;
    if (flowType === 'electronFlow') {
      const byKind: Record<string, number> = {
        signal: 8,
        complexI: 22,
        complexII: 18,
        complexIIQ: 24,
        complexIII: 22,
        complexIV: 22,
        cytochromeC: 16,
        oxygenWater: 14,
      };
      return byKind[part.kind] ?? 10;
    }
    if (flowType === 'protonFlow') {
      if (isProtonPoolPart(part)) {
        if (anchorName === 'protonTopPool') return role === 'to' ? 3 : 2;
        if (anchorName === 'protonBottomPool') return role === 'to' ? 2 : 1;
        return role === 'to' ? 4 : 2;
      }
      const byKind: Record<string, number> = {
        complexI: 12,
        complexIII: 12,
        complexIV: 12,
        atpSynthase: 12,
        ucp: 12,
      };
      if (part.kind in byKind) {
        if (anchorName === 'protonTopPump' || anchorName === 'protonTopIntake') return byKind[part.kind] - 1;
        if (anchorName === 'protonBottomIntake' || anchorName === 'protonBottomExit') return byKind[part.kind] - 2;
        return byKind[part.kind];
      }
      return 0;
    }
    if (flowType === 'transition') return 8;
    return 0;
  };

  const adjustEndpointIntoGraphic = (
    part: PlacedPart | null,
    point: { x: number; y: number },
    fallbackPoint: { x: number; y: number },
    offset: number,
  ) => {
    if (!offset) return point;
    const bounds = part ? getPartBounds(part.uid) : null;
    const target = bounds ? { x: bounds.centerX, y: bounds.centerY } : fallbackPoint;
    const dx = target.x - point.x;
    const dy = target.y - point.y;
    const len = Math.hypot(dx, dy) || 1;
    return {
      x: point.x + (dx / len) * offset,
      y: point.y + (dy / len) * offset,
    };
  };

  const buildRoundedOrthogonalPath = (
    start: { x: number; y: number },
    end: { x: number; y: number },
    mode: 'horizontal-first' | 'vertical-first',
  ) => {
    const corner = mode === 'horizontal-first'
      ? { x: end.x, y: start.y }
      : { x: start.x, y: end.y };

    const dx = end.x - start.x;
    const dy = end.y - start.y;
    const radius = Math.min(10, Math.abs(dx) / 2, Math.abs(dy) / 2);

    if (radius < 1) {
      return mode === 'horizontal-first'
        ? `M ${start.x} ${start.y} L ${corner.x} ${corner.y} L ${end.x} ${end.y}`
        : `M ${start.x} ${start.y} L ${corner.x} ${corner.y} L ${end.x} ${end.y}`;
    }

    const horizontalDir = Math.sign(dx) || 1;
    const verticalDir = Math.sign(dy) || 1;

    if (mode == 'horizontal-first') {
      const lineEnd = { x: corner.x - horizontalDir * radius, y: corner.y };
      const lineStart2 = { x: corner.x, y: corner.y + verticalDir * radius };
      return `M ${start.x} ${start.y} L ${lineEnd.x} ${lineEnd.y} Q ${corner.x} ${corner.y} ${lineStart2.x} ${lineStart2.y} L ${end.x} ${end.y}`;
    }

    const lineEnd = { x: corner.x, y: corner.y - verticalDir * radius };
    const lineStart2 = { x: corner.x + horizontalDir * radius, y: corner.y };
    return `M ${start.x} ${start.y} L ${lineEnd.x} ${lineEnd.y} Q ${corner.x} ${corner.y} ${lineStart2.x} ${lineStart2.y} L ${end.x} ${end.y}`;
  };

  const buildRenderedConnectorPath = (connector: { type: ConnectorType; curveOffset?: number }, fromPart: PlacedPart, toPart: PlacedPart, rawStart: { x: number; y: number }, rawEnd: { x: number; y: number }, fromAnchorName?: string, toAnchorName?: string) => {
    const start = adjustEndpointIntoGraphic(fromPart, rawStart, rawEnd, getVisualContactOffset(fromPart, fromAnchorName, connector.type, 'from'));
    const end = adjustEndpointIntoGraphic(toPart, rawEnd, rawStart, getVisualContactOffset(toPart, toAnchorName, connector.type, 'to'));

    if (connector.type === 'protonFlow') {
      const fromIsPool = isProtonPoolPart(fromPart);
      const toIsPool = isProtonPoolPart(toPart);
      const dx = end.x - start.x;
      const dy = end.y - start.y;
      const verticalSnapThreshold = 24;
      const horizontalSnapThreshold = 12;

      if (Math.abs(dx) <= verticalSnapThreshold) {
        const straightX = (start.x + end.x) / 2;
        return `M ${straightX} ${start.y} L ${straightX} ${end.y}`;
      }
      if (Math.abs(dy) <= horizontalSnapThreshold) {
        const straightY = (start.y + end.y) / 2;
        return `M ${start.x} ${straightY} L ${end.x} ${straightY}`;
      }
      if (fromIsPool && !toIsPool) {
        return buildRoundedOrthogonalPath(start, end, 'horizontal-first');
      }
      if (!fromIsPool && toIsPool) {
        return buildRoundedOrthogonalPath(start, end, 'vertical-first');
      }
      return buildRoundedOrthogonalPath(start, end, 'horizontal-first');
    }

    const emphasizesCytC = connector.type === 'electronFlow' && (fromPart.id === 'cytochrome-c' || toPart.id === 'cytochrome-c');
    const midX = (start.x + end.x) / 2;
    const midY = (start.y + end.y) / 2;
    const curveBoost = connector.curveOffset ?? 0;
    const curveY = connector.type === 'transition'
      ? Math.min(start.y, end.y) - 18 + curveBoost
      : emphasizesCytC
        ? midY - Math.min(Math.abs(end.y - start.y) * 0.12, 12) + curveBoost * 0.35
        : Math.min(start.y, end.y) - Math.min(24, Math.max(12, Math.abs(end.x - start.x) * 0.18)) + curveBoost * 0.65;
    return `M ${start.x} ${start.y} Q ${midX} ${curveY} ${end.x} ${end.y}`;
  };

  const getConnectorEndPoint = (connector: Connector) => {
    const from = getConnectorAnchor(connector.from, 'from', connector.type, connector.to, connector.fromAnchorName, connector.toAnchorName);
    const to = getConnectorAnchor(connector.to, 'to', connector.type, connector.from, connector.toAnchorName, connector.fromAnchorName);
    if (!from || !to) return null;
    return { x: to.x, y: to.y };
  };

  const updateZone = (x: number, y: number): Zone => {
    if (template.layoutMode === 'membrane') {
      if (y < 110) return 'top';
      if (y < 248) return 'membrane';
      return 'bottom';
    }
    if (y < 80) return 'top';
    if (x < template.canvasWidth * 0.3) return 'left';
    if (x < template.canvasWidth * 0.7) return 'center';
    return 'right';
  };

  const resetConnectionState = () => {
    setPendingStart(null);
    setPointerPos(null);
    setHoveredPartUid(null);
    setSnappedTarget(null);
  };

  const finalizeConnection = (fromUid: string, toUid: string) => {
    const fromPart = getPart(fromUid);
    const toPart = getPart(toUid);
    if (!fromPart || !toPart) return;
    const meta = template.connectorOptions.find((item) => item.id === selectedConnectorType);
    if (!meta) return;
    const fromAnchor = getConnectorAnchor(fromUid, 'from', selectedConnectorType, toUid);
    const snappedToAnchor = snappedTarget?.uid === toUid ? snappedTarget.anchor : null;
    const toAnchor = snappedToAnchor
      ?? getConnectorAnchor(toUid, 'to', selectedConnectorType, fromUid, undefined, fromAnchor?.name);
    setConnectors((prev) => [...prev, {
      id: `${fromUid}-${toUid}-${prev.length + 1}`,
      from: fromUid,
      to: toUid,
      label: meta.short,
      color: meta.color,
      type: selectedConnectorType,
      fromAnchorName: fromAnchor?.name,
      toAnchorName: toAnchor?.name,
    }]);
    resetConnectionState();
  };

  const addPart = (partId: string) => {
    const part = template.parts.find((item) => item.id === partId);
    if (!part || lockedPartIds.has(partId)) return;
    const countInZone = placedParts.filter((item) => item.zone === part.defaultZone).length;
    const nextPart = createPlacedPart(part, template, countInZone);
    setPlacedParts((prev) => [...prev, nextPart]);
    setInteractionMode('move');
    setSelectedConnectorId(null);
    resetConnectionState();
    setSelectedId(nextPart.uid);
  };

  const startPointer = (e: React.MouseEvent, uid: string) => {
    if (interactionMode === 'connect') {
      e.preventDefault();
      e.stopPropagation();
      handlePartClick(uid);
      return;
    }
    e.preventDefault();
    const part = getPart(uid);
    if (!part || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    dragRef.current = { uid, offsetX: e.clientX - rect.left - part.x, offsetY: e.clientY - rect.top - part.y };
    if (selectedId !== uid) {
      setSelectedConnectorId(null);
      resetConnectionState();
    }
    setSelectedId(uid);
    setDraggingUid(uid);
  };

  const handlePartClick = (uid: string) => {
    if (interactionMode === 'connect') {
      setSelectedConnectorId(null);
      setSelectedId(uid);
      if (!pendingStart) {
        setPendingStart(uid);
        return;
      }
      if (pendingStart !== uid) {
        finalizeConnection(pendingStart, uid);
        setSelectedId(uid);
      }
      return;
    }

    if (selectedId !== uid) {
      setSelectedConnectorId(null);
      resetConnectionState();
    }
    setSelectedId(uid);
  };

  useEffect(() => {
    const handleWindowMove = (e: MouseEvent) => {
      if (interactionMode === 'connect' && pendingStart && canvasRef.current) {
        const rect = canvasRef.current.getBoundingClientRect();
        const nextPointer = { x: e.clientX - rect.left, y: e.clientY - rect.top };
        setPointerPos(nextPointer);
        const snapped = getSnappedConnectionTarget(nextPointer, pendingStart, selectedConnectorType);
        setSnappedTarget(snapped ? { uid: snapped.uid, anchor: snapped.anchor } : null);
        setHoveredPartUid(snapped?.uid ?? null);
      }
      if (connectorDragRef.current && canvasRef.current) {
        const deltaY = e.clientY - connectorDragRef.current.startY;
        setConnectors((prev) => prev.map((item) => item.id === connectorDragRef.current?.id ? { ...item, curveOffset: clamp(connectorDragRef.current.startOffset + deltaY, -120, 120) } : item));
        return;
      }
      if (!dragRef.current || !canvasRef.current) return;
      const rect = canvasRef.current.getBoundingClientRect();
      const dragPart = getPart(dragRef.current.uid);
      const dims = dragPart ? getPartDimensions(dragPart.kind) : { width: PART_WIDTH, height: PART_HEIGHT };
      const nextX = clamp(e.clientX - rect.left - dragRef.current.offsetX, 8, template.canvasWidth - dims.width - 8);
      const nextY = clamp(e.clientY - rect.top - dragRef.current.offsetY, 6, template.canvasHeight - dims.height - 6);
      setPlacedParts((prev) => prev.map((item) => (item.uid === dragRef.current?.uid ? { ...item, x: nextX, y: nextY, zone: updateZone(nextX, nextY) } : item)));
    };

    const handleWindowUp = () => {
      dragRef.current = null;
      connectorDragRef.current = null;
      setDraggingUid(null);
      const releaseTargetUid = snappedTarget?.uid ?? hoveredPartUid;
      if (interactionMode === 'connect' && pendingStart && releaseTargetUid && releaseTargetUid !== pendingStart) finalizeConnection(pendingStart, releaseTargetUid);
    };

    window.addEventListener('mousemove', handleWindowMove);
    window.addEventListener('mouseup', handleWindowUp);
    return () => {
      window.removeEventListener('mousemove', handleWindowMove);
      window.removeEventListener('mouseup', handleWindowUp);
    };
  }, [interactionMode, hoveredPartUid, pendingStart, selectedConnectorType, snappedTarget, template, setPlacedParts, placedParts]);

  const clearSelection = () => {
    setSelectedId(null);
    setSelectedConnectorId(null);
    setHoveredPartUid(null);
    resetConnectionState();
  };

  const removeSelected = () => {
    if (selectedConnectorId) {
      setConnectors((prev) => prev.filter((item) => item.id !== selectedConnectorId));
      clearSelection();
      return;
    }
    if (!selectedId) return;
    setPlacedParts((prev) => prev.filter((item) => item.uid !== selectedId));
    setConnectors((prev) => prev.filter((item) => item.from !== selectedId && item.to !== selectedId));
    clearSelection();
  };

  const loadExampleAnswer = () => {
    const example = buildExampleModel(template);
    setPlacedParts(example.placedParts);
    setConnectors(example.connectors);
    if (template.exampleAnswers) {
      setAnswers((prev) => ({ ...prev, ...template.exampleAnswers }));
    }
    clearSelection();
  };

  const runPlayback = (result: CheckResult) => {
    clearPlayback();
    const partByUid = new Map(placedParts.map((part) => [part.uid, part]));
    const connectorById = new Map(connectors.map((connector) => [connector.id, connector]));
    let cursor = 120;
    const pushTimer = (fn: () => void, delay: number) => {
      const timerId = window.setTimeout(fn, delay);
      playbackTimersRef.current.push(timerId);
    };
    const activateConnector = (connectorId: string) => {
      const connector = connectorById.get(connectorId);
      if (!connector) return;
      setPlaybackActiveConnectorIds((prev) => (prev.includes(connectorId) ? prev : [...prev, connectorId]));
      setPlaybackActivePartUids((prev) => {
        const next = new Set(prev);
        next.add(connector.from);
        next.add(connector.to);
        return [...next];
      });
    };
    result.activatedPaths.forEach((path) => {
      path.connectorIds.forEach((connectorId) => {
        pushTimer(() => activateConnector(connectorId), cursor);
        cursor += 360;
      });
      cursor += 180;
    });
    result.blockedPaths.forEach((path, pathIndex) => {
      path.connectorIds.forEach((connectorId) => {
        pushTimer(() => activateConnector(connectorId), cursor);
        cursor += 260;
      });
      if (pathIndex === 0) {
        pushTimer(() => {
          const brokePart = placedParts.find((part) => part.id === path.brokeAt)?.uid;
          if (brokePart) {
            setPlaybackBlockedPartUids((prev) => (prev.includes(brokePart) ? prev : [...prev, brokePart]));
          }
          const lastConnectorId = path.connectorIds[path.connectorIds.length - 1];
          const lastConnector = lastConnectorId ? connectorById.get(lastConnectorId) : null;
          const markerPoint = lastConnector ? getConnectorEndPoint(lastConnector) : null;
          if (markerPoint) {
            setBreakMarkers([{ x: markerPoint.x, y: markerPoint.y }]);
          } else if (brokePart) {
            const fallbackCenter = getCenter(brokePart);
            if (fallbackCenter) setBreakMarkers([{ x: fallbackCenter.x, y: fallbackCenter.y }]);
          }
        }, cursor + 60);
      }
      cursor += 240;
    });
    pushTimer(() => {
      setPlaybackActiveConnectorIds(result.activeConnectorIds);
      setPlaybackBlockedConnectorIds(result.blockedConnectorIds);
      setPlaybackActivePartUids(result.activePartUids);
      setPlaybackBlockedPartUids(result.blockedPartUids);
    }, cursor + 120);
  };

  const runCheck = () => {
    const result = evaluateModel(template, placedParts, connectors);
    setCheckResult(result);
    runPlayback(result);
  };

  const activeConnectorIds = new Set(checkResult ? (playbackActiveConnectorIds.length ? playbackActiveConnectorIds : []) : []);
  const blockedConnectorIds = new Set(checkResult ? playbackBlockedConnectorIds : []);
  const activePartUids = new Set(checkResult ? playbackActivePartUids : []);
  const blockedPartUids = new Set(checkResult ? playbackBlockedPartUids : []);
  const producedOutputIds = new Set(checkResult?.outputsProduced ?? []);
  const outputLabelMap: Record<string, string> = { 'nad-plus': 'NAD+', fad: 'FAD', water: 'H₂O', atp: 'ADP + Pi → ATP', heat: 'Heat' };
  const outputPlacements: Array<{ id: string; label: string; x: number; y: number; tone: string }> = [];
  const interactionHelp = interactionMode === 'connect'
    ? pendingStart
      ? 'Click a target to finish this arrow. Drag a placed arrow at its midpoint to reshape it. Double-click a part or arrow to delete it.'
      : 'Arrow mode is on. Choose a flow button, then click one part and a target to draw that arrow type. Click the same flow button again to return to move mode. Double-click a part or arrow to delete it.'
    : 'Move mode: drag parts on the canvas. Connected arrows stay attached while you reposition the model. Use a flow button to switch into arrow-drawing mode. Double-click a part or arrow to delete it.';


  const lockedPartIds = new Set(template.features?.lockedPartIds ?? []);

  const toggleFlowMode = (flowId: ConnectorType) => {
    if (interactionMode === 'connect' && selectedConnectorType === flowId) {
      setInteractionMode('move');
      resetConnectionState();
      return;
    }
    setSelectedConnectorType(flowId);
    setInteractionMode('connect');
    setSelectedConnectorId(null);
  };

  const membraneXs = Array.from({ length: 63 }, (_, i) => 8 + i * 24);
  const protonIconSize = 18;
  const protonRadius = 8;
  const protonStroke = 1.4;
  const protonLabelY = 3.1;
  const protonLabelSize = 8;
  const renderSmallProtonIcon = (id: string, opacity = 1) => (
    <svg width={protonIconSize} height={protonIconSize} viewBox={`0 0 ${protonIconSize} ${protonIconSize}`}>
      <defs>
        <radialGradient id={id} cx="35%" cy="28%" r="70%">
          <stop offset="0%" stopColor="#82ddff" />
          <stop offset="72%" stopColor="#1c73ba" />
          <stop offset="100%" stopColor="#115086" />
        </radialGradient>
      </defs>
      <circle cx={protonIconSize / 2} cy={protonIconSize / 2} r={protonRadius} fill={`url(#${id})`} stroke="#0e4777" strokeWidth={protonStroke} opacity={opacity} />
      <ellipse cx={protonIconSize / 2 - 3.6} cy={protonIconSize / 2 - 4.8} rx="4.8" ry="3.1" fill="rgba(255,255,255,0.22)" opacity={opacity} />
      <text x={protonIconSize / 2} y={protonIconSize / 2 + protonLabelY} textAnchor="middle" fontSize={protonLabelSize} fontWeight="700" fill="#fff" opacity={opacity}>H⁺</text>
    </svg>
  );
  const renderSmallElectronIcon = (id: string, opacity = 1) => (
    <svg width={protonIconSize} height={protonIconSize} viewBox={`0 0 ${protonIconSize} ${protonIconSize}`}>
      <defs>
        <radialGradient id={id} cx="35%" cy="28%" r="70%">
          <stop offset="0%" stopColor="#ff8e8e" />
          <stop offset="72%" stopColor="#d73f3f" />
          <stop offset="100%" stopColor="#8e1717" />
        </radialGradient>
      </defs>
      <circle cx={protonIconSize / 2} cy={protonIconSize / 2} r={protonRadius} fill={`url(#${id})`} stroke="#6f1111" strokeWidth={protonStroke} opacity={opacity} />
      <ellipse cx={protonIconSize / 2 - 3.6} cy={protonIconSize / 2 - 4.8} rx="4.8" ry="3.1" fill="rgba(255,255,255,0.22)" opacity={opacity} />
      <text x={protonIconSize / 2} y={protonIconSize / 2 + protonLabelY} textAnchor="middle" fontSize={7.4} fontWeight="700" fill="#fff" opacity={opacity}>e⁻</text>
    </svg>
  );
  const imsBackgroundProtons = [
    { left: 96, top: 38 }, { left: 152, top: 54 }, { left: 206, top: 34 }, { left: 258, top: 76 },
    { left: 392, top: 44 }, { left: 468, top: 66 }, { left: 522, top: 36 }, { left: 574, top: 82 },
    { left: 702, top: 30 }, { left: 758, top: 58 }, { left: 814, top: 40 }, { left: 866, top: 78 },
    { left: 998, top: 36 }, { left: 1056, top: 60 }, { left: 1114, top: 34 }, { left: 1164, top: 80 },
    { left: 1292, top: 42 }, { left: 1348, top: 62 }, { left: 1408, top: 34 }, { left: 1462, top: 74 },
    { left: 1588, top: 32 }, { left: 1644, top: 54 }, { left: 1700, top: 36 }, { left: 1756, top: 70 },
  ];
  const matrixBackgroundProtons = [
    { left: 142, top: 244 }, { left: 206, top: 274 }, { left: 366, top: 258 }, { left: 512, top: 286 },
    { left: 676, top: 250 }, { left: 838, top: 282 }, { left: 1014, top: 256 }, { left: 1178, top: 292 },
    { left: 1344, top: 246 }, { left: 1508, top: 274 }, { left: 1668, top: 258 }, { left: 1818, top: 288 },
  ];
  const topMembraneY = 126;
  const bottomMembraneY = 206;
  const topHeadY = (i: number) => topMembraneY + Math.sin(i * 0.18) * 3;
  const bottomHeadY = (i: number) => bottomMembraneY + Math.sin(i * 0.18 + 0.34) * 3;

  return (
    <div style={{ display: 'grid', gap: 4, padding: 5 }}>
      <div
        ref={(node) => {
          canvasRef.current = node;
          if (canvasCaptureRef) canvasCaptureRef.current = node;
        }}
        onMouseDown={(e) => {
          if (e.target === e.currentTarget) clearSelection();
        }}
        onMouseMove={(e) => {
          if (interactionMode === 'connect' && pendingStart && canvasRef.current) {
            const rect = canvasRef.current.getBoundingClientRect();
            setPointerPos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
          }
        }}
        style={{
          position: 'relative',
          width: '100%',
          height: template.canvasHeight,
          border: '1px solid #d4a174',
          borderRadius: 22,
          background: template.layoutMode === 'membrane'
            ? 'linear-gradient(180deg, #f7e8be 0%, #f2d492 21%, #de8349 56%, #efaf83 100%)'
            : 'linear-gradient(180deg, #eef2d1 0%, #dbe6a8 22%, #b7d58a 52%, #d7c389 100%)',
          overflow: 'hidden',
          boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.5), inset 0 -36px 88px rgba(186,96,46,0.18), 0 10px 20px rgba(136,90,48,0.08)',
        }}
      >
        {template.layoutMode === 'membrane' ? (
          <>
            <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 0%, rgba(255,255,255,0.18) 0%, rgba(255,255,255,0) 52%)' }} />
            <div style={{ position: 'absolute', top: 18, right: 72, fontSize: 15, fontWeight: 700, color: '#81451f', letterSpacing: 0.2 }}>Intermembrane space</div>
            <div style={{ position: 'absolute', bottom: 12, left: 34, fontSize: 18, fontWeight: 700, color: '#6f3418' }}>Mitochondrial matrix</div>
            <svg viewBox={`0 0 ${template.canvasWidth} ${template.canvasHeight}`} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
              <defs>
                <linearGradient id="tailShade" x1="0" x2="0" y1="0" y2="1">
                  <stop offset="0%" stopColor="#a9c4df" />
                  <stop offset="36%" stopColor="#3d668f" />
                  <stop offset="64%" stopColor="#21405f" />
                  <stop offset="100%" stopColor="#96bbda" />
                </linearGradient>
                <radialGradient id="headFill" cx="50%" cy="35%" r="65%">
                  <stop offset="0%" stopColor="#b7d2ea" />
                  <stop offset="68%" stopColor="#6f98bc" />
                  <stop offset="100%" stopColor="#52789c" />
                </radialGradient>
              </defs>
              {membraneXs.map((x, i) => {
                const yTop = topHeadY(i);
                const yBot = bottomHeadY(i);
                const midY = (yTop + yBot) / 2;
                return (
                  <g key={`lipid-${i}`} opacity="0.98">
                    <ellipse cx={x} cy={yTop} rx="6.8" ry="6.2" fill="url(#headFill)" stroke="#587ea0" strokeWidth="1" />
                    <ellipse cx={x} cy={yBot} rx="6.8" ry="6.2" fill="url(#headFill)" stroke="#587ea0" strokeWidth="1" />
                    <path d={`M ${x - 2.2} ${yTop + 5.6} C ${x - 4.4} ${midY - 18} ${x - 4.8} ${midY + 8} ${x - 2.2} ${yBot - 5.6}`} stroke="url(#tailShade)" strokeWidth="2.35" fill="none" strokeLinecap="round" />
                    <path d={`M ${x + 2.2} ${yTop + 5.6} C ${x + 4.8} ${midY - 10} ${x + 4.2} ${midY + 18} ${x + 2.2} ${yBot - 5.6}`} stroke="url(#tailShade)" strokeWidth="2.35" fill="none" strokeLinecap="round" />
                  </g>
                );
              })}
            </svg>
            {imsBackgroundProtons.map((pt, i) => (
              <div key={`ims-proton-${i}`} style={{ position: 'absolute', left: pt.left, top: pt.top, width: protonIconSize, height: protonIconSize, opacity: 0.32, pointerEvents: 'none' }}>
                {renderSmallProtonIcon(`bgProtonIms-${i}`)}
              </div>
            ))}
            {matrixBackgroundProtons.map((pt, i) => (
              <div key={`matrix-proton-${i}`} style={{ position: 'absolute', left: pt.left, top: pt.top, width: protonIconSize, height: protonIconSize, opacity: 0.22, pointerEvents: 'none' }}>
                {renderSmallProtonIcon(`bgProtonMatrix-${i}`)}
              </div>
            ))}
          </>
        ) : (
          <>
            <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 18% 18%, rgba(255,255,255,0.32) 0%, rgba(255,255,255,0) 38%)' }} />
            <div style={{ position: 'absolute', left: 72, top: 94, width: 350, height: 190, borderRadius: 30, border: '2px dashed rgba(92,133,47,0.45)', background: 'rgba(234,244,202,0.28)' }} />
            <div style={{ position: 'absolute', left: 510, top: 76, width: 420, height: 210, borderRadius: 34, border: '2px dashed rgba(120,110,38,0.38)', background: 'rgba(248,239,182,0.22)' }} />
            <div style={{ position: 'absolute', right: 84, top: 86, width: 360, height: 180, borderRadius: 30, border: '2px dashed rgba(155,117,56,0.36)', background: 'rgba(245,224,180,0.18)' }} />
            <div style={{ position: 'absolute', left: 104, top: 72, color: '#587327', fontSize: 20, fontWeight: 700, opacity: 0.8 }}>Host surface</div>
            <div style={{ position: 'absolute', left: 640, top: 56, color: '#7c6a20', fontSize: 20, fontWeight: 700, opacity: 0.8 }}>Infection stages</div>
            <div style={{ position: 'absolute', right: 132, top: 62, color: '#93672e', fontSize: 20, fontWeight: 700, opacity: 0.8 }}>Release / dispersal</div>
          </>
        )}

        <svg
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) clearSelection();
          }}
          style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: 55 }}>
          <defs>
            <filter id="flowGlow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="2.2" result="blur" />
              <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
            </filter>
            <marker id="arrowhead-gold" markerWidth="6" markerHeight="6" refX="4.35" refY="3" orient="auto" markerUnits="userSpaceOnUse">
              <path d="M0,0 L6,3 L0,6 z" fill="#efb629" />
            </marker>
            <marker id="arrowhead-blue" markerWidth="6" markerHeight="6" refX="5.15" refY="3" orient="auto" markerUnits="userSpaceOnUse">
              <path d="M0,0 L6,3 L0,6 z" fill="#3c88e8" />
            </marker>
            <marker id="arrowhead-purple" markerWidth="6" markerHeight="6" refX="5.15" refY="3" orient="auto" markerUnits="userSpaceOnUse">
              <path d="M0,0 L6,3 L0,6 z" fill="#212121" />
            </marker>
          </defs>

          {connectors.map((connector) => {
            const fromPart = getPart(connector.from);
            const toPart = getPart(connector.to);
            const fromCenter = getConnectorAnchor(connector.from, 'from', connector.type, connector.to, connector.fromAnchorName, connector.toAnchorName) ?? getCenter(connector.from);
            const toCenter = getConnectorAnchor(connector.to, 'to', connector.type, connector.from, connector.toAnchorName, connector.fromAnchorName) ?? getCenter(connector.to);
            if (!fromCenter || !toCenter || !fromPart || !toPart) return null;
            const emphasizesQ = connector.type === 'electronFlow' && (fromPart.id === 'complex-ii-q' || toPart.id === 'complex-ii-q');
            const emphasizesCytC = connector.type === 'electronFlow' && (fromPart.id === 'cytochrome-c' || toPart.id === 'cytochrome-c');
            const d = buildRenderedConnectorPath(connector, fromPart, toPart, fromCenter, toCenter, connector.fromAnchorName, connector.toAnchorName);
            const blockedEnd = adjustEndpointIntoGraphic(toPart, toCenter, fromCenter, getVisualContactOffset(toPart, connector.toAnchorName, connector.type, 'to'));
            const markerEnd = connector.type === 'protonFlow' ? undefined : connector.type === 'transition' ? 'url(#arrowhead-purple)' : 'url(#arrowhead-gold)';
            const highlight = connector.type === 'protonFlow' ? '#d7ebff' : connector.type === 'transition' ? '#f0f0f0' : '#fff0af';
            const isActive = !checkResult ? true : activeConnectorIds.has(connector.id);
            const isBlocked = !!checkResult && blockedConnectorIds.has(connector.id);
            const baseColor = isBlocked ? '#b84545' : isActive ? connector.color : '#c8b29b';
            const emphasisBoost = emphasizesQ ? 0.16 : emphasizesCytC ? 0.08 : 0;
            const glowOpacity = connector.type === 'transition' ? (isActive ? 0.03 : 0.015) : isBlocked ? 0.24 : (isActive ? 0.26 + emphasisBoost : 0.06);
            const bodyWidth = connector.type === 'transition' ? 2.5 : isBlocked ? 3.6 : 3.15 + (emphasizesQ ? 0.95 : emphasizesCytC ? 0.45 : 0);
            const highlightWidth = connector.type === 'transition' ? 0.7 : isBlocked ? 1.0 : 1.15 + (emphasizesQ ? 0.24 : emphasizesCytC ? 0.1 : 0);
            const dashPattern = connector.type === 'transition' ? undefined : connector.type === 'electronFlow' ? '20 58' : '18 52';
            const dashDuration = connector.type === 'electronFlow' ? 0.825 : 0.68;
            const dashBegin = undefined;
            const isSelectedConnector = connector.id === selectedConnectorId;
            return (
              <g key={connector.id} opacity={isActive ? 1 : 0.7}>
                <path
                  d={d}
                  fill="none"
                  stroke="transparent"
                  strokeWidth={20}
                  strokeLinecap="round"
                  style={{ pointerEvents: 'stroke', cursor: interactionMode === 'connect' ? 'pointer' : 'grab' }}
                  onMouseDown={(e) => e.stopPropagation()}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedId(null);
                    setSelectedConnectorId(connector.id);
                  }}
                  onDoubleClick={(e) => {
                    e.stopPropagation();
                    setConnectors((prev) => prev.filter((item) => item.id !== connector.id));
                    setSelectedConnectorId((prev) => (prev === connector.id ? null : prev));
                  }}
                />
                <path d={d} fill="none" stroke={baseColor} strokeWidth={connector.type === 'transition' ? 2.8 : 5.2 + (emphasizesQ ? 0.9 : emphasizesCytC ? 0.45 : 0)} strokeLinecap="round" opacity={Math.min(glowOpacity + 0.03, 0.3)} filter="url(#flowGlow)" />
                <path d={d} fill="none" stroke={isSelectedConnector ? '#111111' : baseColor} strokeWidth={isSelectedConnector ? bodyWidth + 1.2 : bodyWidth} strokeLinecap="round" markerEnd={markerEnd} />
                <path d={d} fill="none" stroke={isSelectedConnector ? '#fff4d6' : isBlocked ? '#ffd6d6' : highlight} strokeWidth={highlightWidth} strokeLinecap="round" opacity="0.98" />
                {connector.type !== 'transition' && isActive ? (
                  <>
                    <path d={d} fill="none" stroke={highlight} strokeWidth={1.25} strokeLinecap="round" strokeDasharray={dashPattern} opacity="0.98">
                      <animate attributeName="stroke-dashoffset" from="0" to="-105" dur={dashDuration} begin={dashBegin} repeatCount="indefinite" />
                    </path>
                    {connector.type === 'protonFlow' ? (
                      <FlowParticle
                        connectorId={connector.id}
                        pathD={d}
                        durationSeconds={1.65}
                        iconSize={protonIconSize}
                        renderIcon={renderSmallProtonIcon}
                        maxDelayMs={0}
                        endPadding={protonIconSize * 0.62}
                      />
                    ) : (
                      <FlowParticle
                        connectorId={connector.id}
                        pathD={d}
                        durationSeconds={dashDuration}
                        iconSize={protonIconSize}
                        renderIcon={renderSmallElectronIcon}
                        maxDelayMs={500}
                        endPadding={protonIconSize * 0.45}
                      />
                    )}
                  </>
                ) : null}
                {isBlocked ? (
                  <g pointerEvents="none" transform={`translate(${blockedEnd.x}, ${blockedEnd.y})`}>
                    <polygon points="0,-18 5,-7 17,-10 9,0 17,10 5,7 0,18 -5,7 -17,10 -9,0 -17,-10 -5,-7" fill="#ff9a5a" stroke="#9f1d13" strokeWidth="2" />
                    <circle r="8" fill="#fff5ef" stroke="#cf3d2f" strokeWidth="2" />
                    <path d="M -4 -4 L 4 4 M 4 -4 L -4 4" stroke="#cf3d2f" strokeWidth="2.2" strokeLinecap="round" />
                  </g>
                ) : null}
              </g>
            );
          })}

          {pendingStart && pointerPos ? (() => {
            const previewCounterpartUid = snappedTarget?.uid ?? hoveredPartUid;
            const previewStart = getConnectorAnchor(pendingStart, 'from', selectedConnectorType, previewCounterpartUid);
            const previewTarget = snappedTarget && snappedTarget.uid !== pendingStart
              ? snappedTarget.anchor
              : hoveredPartUid && hoveredPartUid !== pendingStart
                ? getConnectorAnchor(hoveredPartUid, 'to', selectedConnectorType, pendingStart, undefined, previewStart?.name) ?? getCenter(hoveredPartUid)
                : pointerPos;
            const start = previewStart ?? getCenter(pendingStart);
            if (!start || !previewTarget) return null;
            const option = template.connectorOptions.find((item) => item.id === selectedConnectorType);
            const color = option?.color ?? '#f0b323';
            const markerEnd = selectedConnectorType === 'protonFlow' ? undefined : selectedConnectorType === 'transition' ? 'url(#arrowhead-purple)' : 'url(#arrowhead-gold)';
            const previewHighlight = selectedConnectorType === 'protonFlow' ? '#d7ebff' : selectedConnectorType === 'transition' ? '#f0f0f0' : '#fff0af';
            const startPart = getPart(pendingStart);
            const targetPart = previewCounterpartUid ? getPart(previewCounterpartUid) : null;
            const d = startPart && targetPart
              ? buildRenderedConnectorPath({ type: selectedConnectorType }, startPart, targetPart, start, previewTarget, previewStart?.name, snappedTarget?.anchor.name)
              : `M ${start.x} ${start.y} L ${previewTarget.x} ${previewTarget.y}`;
            return (
              <g>
                <path d={d} fill="none" stroke={color} strokeWidth={selectedConnectorType === 'transition' ? 3.2 : 5.1} strokeLinecap="round" opacity={selectedConnectorType === 'transition' ? 0.06 : 0.16} filter="url(#flowGlow)" />
                <path d={d} fill="none" stroke={color} strokeWidth={selectedConnectorType === 'transition' ? 2.2 : 3.0} strokeLinecap="round" markerEnd={markerEnd} />
                <path d={d} fill="none" stroke={previewHighlight} strokeWidth={selectedConnectorType === 'transition' ? 0.65 : 1.02} strokeLinecap="round" opacity="0.95" />
                {selectedConnectorType !== 'transition' ? (
                  <path d={d} fill="none" stroke={previewHighlight} strokeWidth="1.55" strokeLinecap="round" strokeDasharray={selectedConnectorType === 'electronFlow' ? '15 90' : '12 88'} opacity="0.95">
                    <animate attributeName="stroke-dashoffset" from="0" to="-105" dur={selectedConnectorType === 'electronFlow' ? '1.8s' : '1.55s'} repeatCount="indefinite" />
                  </path>
                ) : null}
              </g>
            );
          })() : null}

          {snappedTarget ? (
            <g pointerEvents="none">
              <circle cx={snappedTarget.anchor.x} cy={snappedTarget.anchor.y} r="8" fill="rgba(255,255,255,0.96)" stroke="#111111" strokeWidth="2" />
              <circle cx={snappedTarget.anchor.x} cy={snappedTarget.anchor.y} r="3.2" fill="#111111" />
            </g>
          ) : null}

        </svg>

        {placedParts.map((part) => {
          const selected = part.uid === selectedId;
          const dims = getPartDimensions(part.kind);
          const hitbox = getPartHitboxDimensions(part.kind);
          return (
            <div
              key={part.uid}
              onMouseDown={(e) => startPointer(e, part.uid)}
              onClick={() => { if (interactionMode !== 'connect') handlePartClick(part.uid); }}
              onDoubleClick={(e) => {
                e.stopPropagation();
                setPlacedParts((prev) => prev.filter((item) => item.uid !== part.uid));
                setConnectors((prev) => prev.filter((item) => item.from !== part.uid && item.to !== part.uid));
                setSelectedId((prev) => (prev === part.uid ? null : prev));
                setSelectedConnectorId(null);
                resetConnectionState();
              }}
              onMouseEnter={() => setHoveredPartUid(part.uid)}
              onMouseLeave={() => setHoveredPartUid((prev) => (prev === part.uid ? null : prev))}
              style={{
                position: 'absolute',
                left: part.x + hitbox.offsetX,
                top: part.y + hitbox.offsetY,
                width: hitbox.width,
                height: hitbox.height,
                cursor: interactionMode === 'connect' ? 'crosshair' : draggingUid === part.uid ? 'grabbing' : 'grab',
                zIndex: 60,
                borderRadius: 18,
                outline: 'none',
                boxShadow: 'none',
                userSelect: 'none',
                overflow: 'visible',
              }}
            >
              <div style={{ position: 'absolute', left: -hitbox.offsetX, top: -hitbox.offsetY, width: dims.width, height: dims.height, pointerEvents: 'none', transform: selected ? 'scale(1.03)' : 'scale(1)', filter: selected ? 'drop-shadow(0 0 0 rgba(0,0,0,0)) drop-shadow(0 6px 12px rgba(101,55,22,0.18))' : activePartUids.has(part.uid) ? 'drop-shadow(0 0 8px rgba(241,194,78,0.55))' : blockedPartUids.has(part.uid) ? 'drop-shadow(0 0 8px rgba(208,55,55,0.45))' : 'none', transition: 'transform 120ms ease, filter 120ms ease' }}>
                <PartGraphic part={part} showLabel={false} />
              </div>
            </div>
          );
        })}


        {hoveredPartUid ? (() => {
          const hoveredPart = placedParts.find((part) => part.uid === hoveredPartUid);
          if (!hoveredPart) return null;
          const dims = getPartDimensions(hoveredPart.kind);
          return (
            <div
              style={{
                position: 'absolute',
                left: hoveredPart.x + dims.width / 2,
                top: hoveredPart.y - 14,
                transform: 'translate(-50%, -100%)',
                zIndex: 140,
                pointerEvents: 'none',
                padding: '4px 8px',
                borderRadius: 10,
                border: '1px solid rgba(104,71,34,0.22)',
                background: 'rgba(255,251,242,0.96)',
                fontSize: 12,
                fontWeight: 800,
                color: '#61361d',
                boxShadow: '0 4px 10px rgba(99,70,39,0.10)',
                whiteSpace: 'nowrap',
              }}
            >
              {hoveredPart.label}
            </div>
          );
        })() : null}


        <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: 120, overflow: 'visible' }}>
          {breakMarkers.map((marker, idx) => {
            const cx = marker.x;
            const cy = marker.y;
            return (
              <g key={`break-${idx}`} pointerEvents="none" opacity="0.99">
                <path d={`M ${cx} ${cy - 20} L ${cx + 5} ${cy - 10} L ${cx + 17} ${cy - 15} L ${cx + 11} ${cy - 3} L ${cx + 24} ${cy + 2} L ${cx + 10} ${cy + 6} L ${cx + 14} ${cy + 19} L ${cx} ${cy + 11} L ${cx - 14} ${cy + 19} L ${cx - 10} ${cy + 6} L ${cx - 24} ${cy + 2} L ${cx - 11} ${cy - 3} L ${cx - 17} ${cy - 15} L ${cx - 5} ${cy - 10} Z`} fill="#f04a3a" stroke="#7f160f" strokeWidth="2" />
                <circle cx={cx} cy={cy} r="8" fill="#fff3e9" />
                <path d={`M ${cx - 4.5} ${cy - 4.5} L ${cx + 4.5} ${cy + 4.5} M ${cx + 4.5} ${cy - 4.5} L ${cx - 4.5} ${cy + 4.5}`} stroke="#b7281d" strokeWidth="2.4" strokeLinecap="round" />
              </g>
            );
          })}
        </svg>

        {outputPlacements.map((item) => (
          <div
            key={item.id}
            style={{
              position: 'absolute',
              left: item.x,
              top: item.y,
              zIndex: 42,
              pointerEvents: 'none',
              padding: item.id === 'adppi' ? '2px 6px' : '4px 8px',
              borderRadius: 18,
              border: '1px solid rgba(104,71,34,0.22)',
              background: 'rgba(255,251,242,0.92)',
              fontSize: item.id === 'adppi' ? 11 : 13,
              fontWeight: 800,
              color: item.tone,
              boxShadow: '0 4px 10px rgba(99,70,39,0.08)',
            }}
          >
            {item.label}
          </div>
        ))}

      </div>

      <div style={{ display: 'grid', gap: 4, padding: '0 4px' }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, alignItems: 'center' }}>
          {template.connectorOptions.map((option) => {
            const active = interactionMode === 'connect' && selectedConnectorType === option.id;
            return (
              <Button key={option.id} onClick={() => toggleFlowMode(option.id)} primary={active}>
                {option.label}
              </Button>
            );
          })}
          <Button onClick={runCheck}>Check your work</Button>
          <Button onClick={() => { setPlacedParts([]); setConnectors([]); setCheckResult(null); clearPlayback(); clearSelection(); setInteractionMode('move'); }}>Reset model</Button>
          <Button onClick={removeSelected} disabled={!selectedId && !selectedConnectorId}>{selectedConnectorId ? 'Delete selected arrow' : 'Delete selected'}</Button>
          <Button onClick={() => setConnectors([])} disabled={!connectors.length}>Clear arrows</Button>
        </div>
        <div style={{ fontSize: 11, color: '#80563a', paddingLeft: 2, lineHeight: 1.3 }}>{interactionHelp}</div>
      </div>

      {checkResult ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'minmax(260px, 1fr)', gap: 8, padding: '0 4px' }}>
          <div style={{ border: '1px solid #d99b9b', borderRadius: 18, padding: '8px 10px', background: 'rgba(255,238,238,0.9)' }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4, color: '#8f2e2e' }}>Where flow broke</div>
            <div style={{ fontSize: 11, color: '#7d5d42', lineHeight: 1.35, marginBottom: 6 }}>You can keep editing after checking. Working flow animates directly on the canvas, and the red break symbol shows the last correct point before the pathway stops.</div>
            {checkResult.placementWarnings[0] ? <div style={{ fontSize: 11, color: '#8c6a4b', marginBottom: 6 }}>Placement: {checkResult.placementWarnings[0]}</div> : null}
            <div style={{ fontSize: 11, lineHeight: 1.4 }}>{checkResult.blockedPaths.length ? checkResult.blockedPaths.slice(0, 4).map((item) => <div key={item.id}>• {item.reason}</div>) : 'No broken paths detected.'}</div>
            {checkResult.overallStatus === 'success' ? <div style={{ fontSize: 11, color: '#2f6a37', marginTop: 6, fontWeight: 700 }}>Normal system complete.</div> : null}
          </div>
        </div>
      ) : null}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(56px, 1fr))', gap: 4, padding: '2px 2px 3px' }}>
        {template.parts.map((part) => {
          const locked = lockedPartIds.has(part.id);
          return (
            <div key={part.id} style={locked ? { opacity: 0.45, filter: 'grayscale(0.65)' } : undefined}>
              <PaletteToken part={part} onAdd={locked ? () => {} : addPart} />
              {locked ? <div style={{ textAlign: 'center', fontSize: 10, color: '#8d847a', marginTop: 2 }}>Later</div> : null}
            </div>
          );
        })}
      </div>
    </div>
  );
}
