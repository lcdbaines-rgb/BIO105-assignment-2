import type { PartDef } from '../data/model';
import { PartGraphic } from './PartGraphic';

export function PaletteToken({ part, onAdd }: { part: PartDef; onAdd: (partId: string) => void }) {
  return (
    <button
      onClick={() => onAdd(part.id)}
      style={{
        border: '1px solid #dbb58b',
        borderRadius: 10,
        padding: '1px',
        background: 'linear-gradient(180deg, rgba(255,249,239,0.98) 0%, rgba(243,221,191,0.95) 100%)',
        cursor: 'pointer',
        minHeight: 44,
        minWidth: 52,
        width: '100%',
        display: 'grid',
        placeItems: 'center',
        boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.82), 0 2px 4px rgba(122,79,39,0.05)',
      }}
    >
      <PartGraphic part={part} compact />
    </button>
  );
}
