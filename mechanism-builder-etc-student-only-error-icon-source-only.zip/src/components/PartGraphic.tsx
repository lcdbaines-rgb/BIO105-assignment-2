import type { PartDef } from '../data/model';

export function PartGraphic({ part, compact = false, showLabel = true }: { part: PartDef; compact?: boolean; showLabel?: boolean }) {
  const isMembraneProtein = ['complexI', 'complexII', 'complexIIQ', 'complexIII', 'complexIV', 'atpSynthase', 'ucp'].includes(part.kind);
  const isLifecycleWide = ['stage', 'host'].includes(part.kind);
  const size = compact ? (isMembraneProtein ? 70 : isLifecycleWide ? 64 : 48) : isMembraneProtein ? 148 : isLifecycleWide ? 96 : 70;
  const labelSize = compact ? 9.5 : 20;
  let graphic: React.ReactNode = null;

  switch (part.kind) {
    case 'complexI': {
      graphic = (
        <svg width={size} height={size} viewBox="0 0 90 90">
          <defs>
            <linearGradient id="ci" x1="0" x2="1" y1="0" y2="1">
              <stop offset="0%" stopColor="#ffd7ba" />
              <stop offset="55%" stopColor="#efab7c" />
              <stop offset="100%" stopColor="#d77649" />
            </linearGradient>
          </defs>
          <path d="M26 14 C15 18, 13 30, 14 47 C14 62, 22 72, 34 75 C47 78, 60 69, 61 54 L61 22 C57 13, 39 10, 26 14 Z" fill="url(#ci)" stroke="#955631" strokeWidth="2.2" />
          <ellipse cx="38" cy="19" rx="14" ry="5" fill="rgba(255,255,255,0.28)" />
          <text x="39" y="52" textAnchor="middle" fontSize="24" fontWeight="700" fill="#6a371d">I</text>
        </svg>
      );
      break;
    }
    case 'complexII': {
      graphic = (
        <svg width={size} height={size} viewBox="0 0 90 90">
          <defs>
            <linearGradient id="cii" x1="0" x2="1" y1="0" y2="1">
              <stop offset="0%" stopColor="#ffdfe0" />
              <stop offset="60%" stopColor="#f2b3a5" />
              <stop offset="100%" stopColor="#d98979" />
            </linearGradient>
          </defs>
          <path d="M27 15 C18 20, 17 33, 19 49 C20 62, 28 72, 41 74 C53 76, 63 69, 63 55 L61 23 C57 13, 39 11, 27 15 Z" fill="url(#cii)" stroke="#986253" strokeWidth="2.2" />
          <ellipse cx="39" cy="20" rx="14" ry="5" fill="rgba(255,255,255,0.28)" />
          <text x="41" y="52" textAnchor="middle" fontSize="24" fontWeight="700" fill="#7b4331">II</text>
        </svg>
      );
      break;
    }
    case 'complexIIQ': {
      graphic = (
        <svg width={size} height={size} viewBox="0 0 90 96">
          <defs>
            <linearGradient id="ciiqBody" x1="0" x2="1" y1="0" y2="1">
              <stop offset="0%" stopColor="#ffe2e0" />
              <stop offset="60%" stopColor="#f0b2a4" />
              <stop offset="100%" stopColor="#d68778" />
            </linearGradient>
            <linearGradient id="qorb" x1="0" x2="1" y1="0" y2="1">
              <stop offset="0%" stopColor="#d5b7ff" />
              <stop offset="100%" stopColor="#7d56bb" />
            </linearGradient>
          </defs>
          <path d="M33 24 C24 29, 23 42, 24 56 C25 69, 31 79, 42 81 C53 83, 61 76, 61 63 L60 32 C57 23, 44 20, 33 24 Z" fill="url(#ciiqBody)" stroke="#986253" strokeWidth="2.2" />
          <ellipse cx="45" cy="29" rx="12" ry="4.5" fill="rgba(255,255,255,0.28)" />
          <text x="45" y="59" textAnchor="middle" fontSize="22" fontWeight="700" fill="#7b4331">II</text>
          <ellipse cx="45" cy="15" rx="20" ry="13" fill="url(#qorb)" stroke="#5e3f93" strokeWidth="2.2" />
          <text x="45" y="20" textAnchor="middle" fontSize="18" fontWeight="700" fill="#fff8ff">Q</text>
        </svg>
      );
      break;
    }
    case 'complexIII': {
      graphic = (
        <svg width={size} height={size} viewBox="0 0 90 90">
          <defs>
            <linearGradient id="ciii" x1="0" x2="1" y1="0" y2="1">
              <stop offset="0%" stopColor="#efe6ff" />
              <stop offset="58%" stopColor="#c1b1e5" />
              <stop offset="100%" stopColor="#9682c7" />
            </linearGradient>
          </defs>
          <path d="M21 19 C28 11, 44 10, 56 15 C67 21, 69 32, 68 48 C67 61, 60 71, 48 73 C35 75, 22 69, 18 56 C15 45, 14 27, 21 19 Z" fill="url(#ciii)" stroke="#78639f" strokeWidth="2.2" />
          <ellipse cx="40" cy="20" rx="16" ry="5.5" fill="rgba(255,255,255,0.28)" />
          <text x="45" y="52" textAnchor="middle" fontSize="24" fontWeight="700" fill="#6e4f8f">III</text>
        </svg>
      );
      break;
    }
    case 'complexIV': {
      graphic = (
        <svg width={size} height={size} viewBox="0 0 90 90">
          <defs>
            <linearGradient id="civ" x1="0" x2="1" y1="0" y2="1">
              <stop offset="0%" stopColor="#dff3ff" />
              <stop offset="60%" stopColor="#98cbe8" />
              <stop offset="100%" stopColor="#63a9cf" />
            </linearGradient>
          </defs>
          <path d="M18 36 C20 24, 31 14, 47 13 C62 12, 74 19, 77 31 C81 47, 74 60, 59 65 C42 72, 22 65, 18 52 C16 47, 16 40, 18 36 Z" fill="url(#civ)" stroke="#5c9abc" strokeWidth="2.2" />
          <ellipse cx="43" cy="24" rx="18" ry="6" fill="rgba(255,255,255,0.28)" />
          <text x="45" y="49" textAnchor="middle" fontSize="24" fontWeight="700" fill="#3e7698">IV</text>
        </svg>
      );
      break;
    }
    case 'coenzymeQ':
      graphic = (
        <svg width={size} height={size} viewBox="0 0 90 90">
          <defs>
            <linearGradient id="coqgrad2" x1="0" x2="1" y1="0" y2="1">
              <stop offset="0%" stopColor="#cfacff" />
              <stop offset="100%" stopColor="#7d56bb" />
            </linearGradient>
          </defs>
          <ellipse cx="42" cy="41" rx="21" ry="13" fill="url(#coqgrad2)" stroke="#5e3f93" strokeWidth="2" />
          <text x="42" y="46" textAnchor="middle" fontSize="20" fontWeight="700" fill="#fff8ff">Q</text>
        </svg>
      );
      break;
    case 'cytochromeC':
      graphic = (
        <svg width={compact ? size + 28 : size + 76} height={compact ? size * 0.86 : size * 0.84} viewBox="0 0 220 94">
          <ellipse cx="110" cy="47" rx="66" ry="29" fill="#f1d78b" stroke="#a8842d" strokeWidth="2.8" />
          <ellipse cx="86" cy="35" rx="20" ry="7.5" fill="rgba(255,255,255,0.26)" />
          <text x="110" y="56" textAnchor="middle" fontSize="36" fontWeight="700" fill="#715614">c</text>
        </svg>
      );
      break;
    case 'protons': {
      const low = part.id === 'low-protons';
      const protonPts = low ? [{x:34,y:45},{x:74,y:39}] : [{x:18,y:45},{x:55,y:33},{x:92,y:47}];
      const radius = low ? 13 : 14;
      graphic = (
        <svg width={size} height={size} viewBox="0 0 110 90">
          <defs>
            <radialGradient id={low ? 'protonGlowLow' : 'protonGlow2'} cx="35%" cy="28%" r="70%">
              <stop offset="0%" stopColor={low ? '#b4e8ff' : '#82ddff'} />
              <stop offset="72%" stopColor={low ? '#4d98cf' : '#1c73ba'} />
              <stop offset="100%" stopColor={low ? '#2c6fa0' : '#115086'} />
            </radialGradient>
          </defs>
          {protonPts.map((pt, idx) => (
            <g key={idx}>
              <circle cx={pt.x} cy={pt.y} r={radius} fill={`url(#${low ? 'protonGlowLow' : 'protonGlow2'})`} stroke="#0e4777" strokeWidth="2" />
              <ellipse cx={pt.x - 4.5} cy={pt.y - 6.3} rx="6.2" ry="4.1" fill="rgba(255,255,255,0.22)" />
              <text x={pt.x} y={pt.y + 4.5} textAnchor="middle" fontSize="10.5" fontWeight="700" fill="#fff">H⁺</text>
            </g>
          ))}
        </svg>
      );
      break;
    }
    case 'atpSynthase':
      graphic = (
        <svg width={size} height={size} viewBox="0 0 100 140">
          <defs>
            <linearGradient id="atpTopRevert" x1="0" x2="1" y1="0" y2="1">
              <stop offset="0%" stopColor="#ffbf70" />
              <stop offset="100%" stopColor="#e48a31" />
            </linearGradient>
            <linearGradient id="atpBodyRevert" x1="0" x2="1" y1="0" y2="1">
              <stop offset="0%" stopColor="#f7b464" />
              <stop offset="100%" stopColor="#d97c2a" />
            </linearGradient>
          </defs>
          <path d="M39 10 C35 14, 34 20, 34 28 L34 42 C34 49, 38 54, 44 54 L56 54 C62 54, 66 49, 66 42 L66 28 C66 20, 65 14, 61 10 Z" fill="url(#atpTopRevert)" stroke="#9e5a21" strokeWidth="2" />
          <rect x="46" y="54" width="8" height="18" rx="4" fill="#cf7b2c" stroke="#9e5a21" strokeWidth="2" />
          <path d="M31 72 C22 76, 18 85, 18 95 C18 108, 23 116, 32 120 C38 123, 44 124, 50 124 C56 124, 62 123, 68 120 C77 116, 82 108, 82 95 C82 85, 78 76, 69 72 C63 69, 57 68, 50 68 C43 68, 37 69, 31 72 Z" fill="url(#atpBodyRevert)" stroke="#9e5a21" strokeWidth="2.2" />
          <path d="M24 75 C17 77, 14 83, 14 90 L14 104 C14 110, 18 115, 24 117 L29 119 L29 87 C29 81, 30 77, 32 74 Z" fill="url(#atpBodyRevert)" stroke="#9e5a21" strokeWidth="2" />
          <path d="M76 75 C83 77, 86 83, 86 90 L86 104 C86 110, 82 115, 76 117 L71 119 L71 87 C71 81, 70 77, 68 74 Z" fill="url(#atpBodyRevert)" stroke="#9e5a21" strokeWidth="2" />
          <ellipse cx="49" cy="17" rx="11" ry="4" fill="rgba(255,255,255,0.24)" />
        </svg>
      );
      break;
    case 'ucp': {
      const isUcp1 = part.id === 'ucp1';
      const gradId = isUcp1 ? 'ucp1grad' : 'ucp3grad';
      const stroke = isUcp1 ? '#3f7f76' : '#ab5e88';
      const dash = isUcp1 ? '#2e635d' : '#92486f';
      graphic = (
        <svg width={size} height={size} viewBox="0 0 90 90">
          <defs>
            <linearGradient id={gradId} x1="0" x2="1" y1="0" y2="1">
              {isUcp1 ? (
                <>
                  <stop offset="0%" stopColor="#d8fff2" />
                  <stop offset="100%" stopColor="#7cc7aa" />
                </>
              ) : (
                <>
                  <stop offset="0%" stopColor="#ffdced" />
                  <stop offset="100%" stopColor="#e197bf" />
                </>
              )}
            </linearGradient>
          </defs>
          <path d="M31 13 C24 19, 23 29, 25 38 C27 45, 26 54, 32 63 C38 68, 48 68, 56 62 C63 56, 63 47, 65 38 C66 28, 64 18, 56 13 C48 9, 38 9, 31 13 Z" fill={`url(#${gradId})`} stroke={stroke} strokeWidth="2" />
          <path d="M45 20 L45 61" stroke={dash} strokeWidth="3" strokeDasharray="5 5" />
        </svg>
      );
      break;
    }
    case 'signal':
      if (part.id === 'nadh') {
        graphic = (
          <svg width={compact ? size + 24 : size + 54} height={compact ? size * 0.88 : size * 0.84} viewBox="0 0 214 98">
            <defs>
              <radialGradient id="nadh-electron-grad" cx="35%" cy="28%" r="70%">
                <stop offset="0%" stopColor="#ff8e8e" />
                <stop offset="72%" stopColor="#d73f3f" />
                <stop offset="100%" stopColor="#8e1717" />
              </radialGradient>
            </defs>
            <ellipse cx="54" cy="50" rx="37" ry="20" fill="#91aaf4" stroke="#3b56aa" strokeWidth="2.4" />
            <text x="54" y="55" textAnchor="middle" fontSize="18" fontWeight="700" fill="#23366f">NADH</text>
            <circle cx="102" cy="31" r="11" fill="url(#nadh-electron-grad)" stroke="#6f1111" strokeWidth="1.6" />
            <text x="102" y="35" textAnchor="middle" fontSize="11" fontWeight="700" fill="#fff">e⁻</text>
            <path d="M118 50 L156 50" stroke="#4866c9" strokeWidth="4.5" strokeLinecap="round" />
            <path d="M156 50 L145 43 M156 50 L145 57" stroke="#4866c9" strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" />
            <ellipse cx="182" cy="50" rx="26" ry="16" fill="#c5d2fb" stroke="#5268b6" strokeWidth="2" />
            <text x="182" y="54" textAnchor="middle" fontSize="13" fontWeight="700" fill="#2f4585">NAD⁺</text>
          </svg>
        );
      } else if (part.id === 'nad-plus') {
        graphic = (
          <svg width={size} height={size} viewBox="0 0 90 90">
            <ellipse cx="45" cy="43" rx="29" ry="16" fill="#c5d2fb" stroke="#5268b6" strokeWidth="2" />
            <text x="45" y="47" textAnchor="middle" fontSize="13" fontWeight="700" fill="#2f4585">NAD+</text>
          </svg>
        );
      } else if (part.id === 'fadh2') {
        graphic = (
          <svg width={compact ? size + 24 : size + 54} height={compact ? size * 0.88 : size * 0.84} viewBox="0 0 214 98">
            <defs>
              <radialGradient id="fadh2-electron-grad" cx="35%" cy="28%" r="70%">
                <stop offset="0%" stopColor="#ff8e8e" />
                <stop offset="72%" stopColor="#d73f3f" />
                <stop offset="100%" stopColor="#8e1717" />
              </radialGradient>
            </defs>
            <ellipse cx="56" cy="50" rx="39" ry="20" fill="#f0d681" stroke="#b38423" strokeWidth="2.4" />
            <text x="56" y="55" textAnchor="middle" fontSize="17" fontWeight="700" fill="#6d4f18">FADH₂</text>
            <circle cx="105" cy="31" r="11" fill="url(#fadh2-electron-grad)" stroke="#6f1111" strokeWidth="1.6" />
            <text x="105" y="35" textAnchor="middle" fontSize="11" fontWeight="700" fill="#fff">e⁻</text>
            <path d="M121 50 L159 50" stroke="#bb8d24" strokeWidth="4.5" strokeLinecap="round" />
            <path d="M159 50 L148 43 M159 50 L148 57" stroke="#bb8d24" strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" />
            <ellipse cx="183" cy="50" rx="24" ry="16" fill="#f6e2a7" stroke="#b58c38" strokeWidth="2" />
            <text x="183" y="54" textAnchor="middle" fontSize="14" fontWeight="700" fill="#785a1d">FAD</text>
          </svg>
        );
      } else if (part.id === 'fad') {
        graphic = (
          <svg width={size} height={size} viewBox="0 0 90 90">
            <ellipse cx="45" cy="43" rx="26" ry="16" fill="#f6e2a7" stroke="#b58c38" strokeWidth="2" />
            <text x="45" y="47" textAnchor="middle" fontSize="14" fontWeight="700" fill="#785a1d">FAD</text>
          </svg>
        );
      } else {
        graphic = (
          <svg width={size} height={size} viewBox="0 0 90 90">
            <defs><linearGradient id="mdmagrad2" x1="0" x2="1" y1="0" y2="1"><stop offset="0%" stopColor="#9d7ad5" /><stop offset="100%" stopColor="#6946a8" /></linearGradient></defs>
            <ellipse cx="45" cy="43" rx="31" ry="17" fill="url(#mdmagrad2)" stroke="#58388d" strokeWidth="2" />
            <text x="45" y="49" textAnchor="middle" fontSize="18" fontWeight="700" fill="#fff">MDMA</text>
          </svg>
        );
      }
      break;
    case 'heat':
      graphic = (
        <svg width={size} height={size} viewBox="0 0 90 90">
          <path d="M31 72 C18 63, 20 49, 31 40 C28 51, 39 50, 40 33 C49 42, 54 52, 50 61 C46 68, 40 72, 31 72 Z" fill="#f7ab28" stroke="#d17f12" strokeWidth="1.2" />
          <path d="M50 68 C41 59, 43 48, 51 40 C48 47, 56 47, 57 36 C64 44, 66 51, 62 58 C60 63, 56 66, 50 68 Z" fill="#ef6a39" stroke="#c34d22" strokeWidth="1.2" />
        </svg>
      );
      break;

    case 'oxygen':
      graphic = (
        <svg width={size} height={size} viewBox="0 0 90 90">
          <circle cx="34" cy="45" r="18" fill="#d9bfdc" stroke="#8b6b92" strokeWidth="2" />
          <circle cx="56" cy="45" r="18" fill="#d0b2d4" stroke="#8b6b92" strokeWidth="2" />
          <text x="45" y="51" textAnchor="middle" fontSize="18" fontWeight="700" fill="#5f4367">O₂</text>
        </svg>
      );
      break;
    case 'water':
      graphic = (
        <svg width={size} height={size} viewBox="0 0 90 90">
          <ellipse cx="45" cy="46" rx="28" ry="18" fill="#a9d8ef" stroke="#5e9bbb" strokeWidth="2" />
          <text x="45" y="52" textAnchor="middle" fontSize="18" fontWeight="700" fill="#235f80">H₂O</text>
        </svg>
      );
      break;

    case 'oxygenWater':
      graphic = (
        <svg width={compact ? size + 18 : size + 54} height={compact ? size * 0.9 : size * 0.82} viewBox="0 0 220 96">
          <defs>
            <linearGradient id="oxywaterArrow" x1="0" x2="1" y1="0" y2="0">
              <stop offset="0%" stopColor="#b993d0" />
              <stop offset="100%" stopColor="#7bbad7" />
            </linearGradient>
          </defs>
          <g>
            <circle cx="56" cy="48" r="24" fill="#d9bfdc" stroke="#8b6b92" strokeWidth="2.6" />
            <circle cx="84" cy="48" r="24" fill="#d0b2d4" stroke="#8b6b92" strokeWidth="2.6" />
            <text x="70" y="55" textAnchor="middle" fontSize="26" fontWeight="700" fill="#5f4367">O₂</text>
          </g>
          <path d="M108 48 L158 48" stroke="url(#oxywaterArrow)" strokeWidth="5.5" strokeLinecap="round" />
          <path d="M158 48 L146 40 M158 48 L146 56" stroke="url(#oxywaterArrow)" strokeWidth="5.5" strokeLinecap="round" strokeLinejoin="round" />
          <g>
            <ellipse cx="184" cy="48" rx="28" ry="20" fill="#a9d8ef" stroke="#5e9bbb" strokeWidth="2.6" />
            <text x="184" y="55" textAnchor="middle" fontSize="22" fontWeight="700" fill="#235f80">H₂O</text>
          </g>
        </svg>
      );
      break;

    case 'atpCycle':
      graphic = (
        <svg width={compact ? size + 26 : size + 58} height={compact ? size * 0.92 : size * 0.84} viewBox="0 0 232 98">
          <defs>
            <radialGradient id="atpCycleGrad" cx="50%" cy="50%" r="70%">
              <stop offset="0%" stopColor="#fff6b6" />
              <stop offset="72%" stopColor="#f6d25c" />
              <stop offset="100%" stopColor="#e0a120" />
            </radialGradient>
          </defs>
          <ellipse cx="44" cy="38" rx="30" ry="16" fill="#efd896" stroke="#b98d2d" strokeWidth="2.2" />
          <text x="44" y="43" textAnchor="middle" fontSize="15" fontWeight="700" fill="#7a5a12">ADP</text>
          <circle cx="89" cy="38" r="13" fill="#e7f0c0" stroke="#96a85e" strokeWidth="2" />
          <text x="89" y="43" textAnchor="middle" fontSize="15" fontWeight="700" fill="#5f6d2f">Pi</text>
          <path d="M109 38 L157 38" stroke="#b47d12" strokeWidth="5" strokeLinecap="round" />
          <path d="M157 38 L145 30 M157 38 L145 46" stroke="#b47d12" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
          <ellipse cx="185" cy="38" rx="32" ry="18" fill="url(#atpCycleGrad)" stroke="#b57a14" strokeWidth="2.2" />
          <text x="185" y="44" textAnchor="middle" fontSize="18" fontWeight="700" fill="#7b4f08">ATP</text>
        </svg>
      );
      break;

    case 'stage':
      graphic = (
        <svg width={size + (compact ? 12 : 28)} height={compact ? size * 0.78 : size * 0.74} viewBox="0 0 120 76">
          <rect x="6" y="8" rx="18" ry="18" width="108" height="56" fill="#f5d88d" stroke="#ad8432" strokeWidth="2.4" />
          <rect x="14" y="16" rx="14" ry="14" width="92" height="40" fill="rgba(255,248,220,0.45)" />
        </svg>
      );
      break;
    case 'host':
      graphic = (
        <svg width={size + (compact ? 18 : 36)} height={compact ? size * 0.8 : size * 0.74} viewBox="0 0 130 78">
          <path d="M18 58 C18 32, 42 18, 68 18 C95 18, 114 32, 114 57 C104 61, 93 65, 78 67 C54 70, 31 66, 18 58 Z" fill="#8fba54" stroke="#537e2c" strokeWidth="2.5" />
          <path d="M66 24 C66 38, 63 51, 56 64" fill="none" stroke="#537e2c" strokeWidth="2.3" />
        </svg>
      );
      break;
    case 'spore':
      graphic = (
        <svg width={size} height={size} viewBox="0 0 90 90">
          <ellipse cx="45" cy="45" rx="24" ry="17" fill="#f4cf53" stroke="#a57b1b" strokeWidth="2.2" />
          <ellipse cx="38" cy="39" rx="8" ry="5" fill="rgba(255,255,255,0.28)" />
          <circle cx="45" cy="45" r="4.5" fill="#9f6e16" />
        </svg>
      );
      break;

    case 'atp':
      graphic = (
        <svg width={size} height={size} viewBox="0 0 90 90">
          <defs>
            <radialGradient id="atpglow2" cx="50%" cy="50%" r="70%">
              <stop offset="0%" stopColor="#fff9b2" />
              <stop offset="70%" stopColor="#f8d257" />
              <stop offset="100%" stopColor="#e4a622" />
            </radialGradient>
          </defs>
          <ellipse cx="45" cy="44" rx="26" ry="17" fill="url(#atpglow2)" stroke="#b57a14" strokeWidth="2" />
          <text x="45" y="50" textAnchor="middle" fontSize="20" fontWeight="700" fill="#7b4f08">ATP</text>
        </svg>
      );
      break;
  }

  const protonLabelAbove = part.kind === 'protons' && part.id === 'protons';
  const labelNode = (
    <div
      style={{
        fontSize: labelSize,
        fontWeight: 800,
        lineHeight: 1.05,
        textAlign: 'center',
        color: '#61361d',
        textShadow: compact ? 'none' : '0 1px 0 rgba(255,255,255,0.45)',
        background: compact ? 'rgba(255,247,235,0.88)' : 'transparent',
        padding: compact ? '1px 4px' : 0,
        borderRadius: compact ? 8 : 0,
        maxWidth: compact ? 64 : 130,
        whiteSpace: 'normal',
        marginBottom: protonLabelAbove ? (compact ? 1 : 2) : 0,
        marginTop: !protonLabelAbove && part.kind === 'protons' ? (compact ? 3 : 6) : 0,
      }}
    >
      {part.label}
    </div>
  );

  return (
    <div style={{ display: 'grid', justifyItems: 'center', gap: compact ? 2 : 4 }}>
      {showLabel && protonLabelAbove ? labelNode : null}
      {graphic}
      {showLabel && !protonLabelAbove ? labelNode : null}
    </div>
  );
}
