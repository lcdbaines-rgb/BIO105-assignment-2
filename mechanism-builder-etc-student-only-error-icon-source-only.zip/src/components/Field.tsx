import type { FieldDef } from '../data/model';

const labelStyle = {
  fontSize: 15,
  fontWeight: 700,
  color: '#75421e',
} as const;

const inputShell = {
  width: '100%',
  borderRadius: 18,
  border: '1px solid #d7ad7f',
  padding: '13px 15px',
  fontSize: 15,
  background: 'linear-gradient(180deg, #fff7ea 0%, #f3dfc1 100%)',
  color: '#633719',
  boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.72), 0 1px 2px rgba(127,80,39,0.04)',
} as const;

export function Field({ field, value, onChange }: { field: FieldDef; value: unknown; onChange: (key: string, value: unknown) => void }) {
  if (field.type === 'textarea') {
    return (
      <div style={{ display: 'grid', gap: 9 }}>
        <label style={labelStyle}>{field.label}</label>
        <textarea
          value={(value as string) || ''}
          onChange={(e) => onChange(field.key, e.target.value)}
          rows={5}
          style={{ ...inputShell, resize: 'vertical', fontFamily: 'inherit', lineHeight: 1.45 }}
        />
      </div>
    );
  }

  if (field.type === 'checkbox') {
    return (
      <label
        style={{
          display: 'flex',
          gap: 12,
          alignItems: 'flex-start',
          border: '1px solid #d7ad7f',
          borderRadius: 20,
          padding: 15,
          background: 'linear-gradient(180deg, #fff8ec 0%, #f4dfc1 100%)',
          color: '#6a3c1d',
          boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.72), 0 1px 2px rgba(127,80,39,0.04)',
        }}
      >
        <input type="checkbox" checked={!!value} onChange={(e) => onChange(field.key, e.target.checked)} style={{ marginTop: 3 }} />
        <span style={{ fontSize: 15, lineHeight: 1.35 }}>{field.label}</span>
      </label>
    );
  }

  return (
    <div style={{ display: 'grid', gap: 9 }}>
      <label style={labelStyle}>{field.label}</label>
      <select value={(value as string) || ''} onChange={(e) => onChange(field.key, e.target.value)} style={inputShell}>
        <option value="">Select</option>
        {field.options?.map((opt) => (
          <option key={opt} value={opt}>
            {opt}
          </option>
        ))}
      </select>
    </div>
  );
}
