import React from 'react';

export function Card({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div
      style={{
        background: 'linear-gradient(180deg, #f8ebd8 0%, #f2ddbf 100%)',
        border: '1px solid #ddb387',
        borderRadius: 28,
        boxShadow: '0 16px 38px rgba(111, 67, 28, 0.12), inset 0 1px 0 rgba(255,255,255,0.75), inset 0 -1px 0 rgba(192,132,78,0.12)',
        ...style,
      }}
    >
      {children}
    </div>
  );
}

export function Button({ children, onClick, disabled, primary = false, success = false }: { children: React.ReactNode; onClick?: () => void; disabled?: boolean; primary?: boolean; success?: boolean }) {
  const border = success ? '#5c8f47' : primary ? '#2e648b' : '#cda57b';
  const background = disabled
    ? '#eadccc'
    : success
      ? 'linear-gradient(180deg, #7fbe67 0%, #4e9542 100%)'
      : primary
        ? 'linear-gradient(180deg, #4f88b8 0%, #2d6188 100%)'
        : 'linear-gradient(180deg, #fff4e5 0%, #f3ddbf 100%)';
  const color = disabled ? '#9f8567' : success || primary ? '#fff' : '#7a4a24';

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        borderRadius: 18,
        padding: '12px 18px',
        fontSize: 15,
        fontWeight: 700,
        letterSpacing: 0.1,
        border: `1px solid ${border}`,
        background,
        color,
        boxShadow: disabled ? 'none' : 'inset 0 1px 0 rgba(255,255,255,0.52), 0 2px 6px rgba(125,85,42,0.08)',
        cursor: disabled ? 'not-allowed' : 'pointer',
      }}
    >
      {children}
    </button>
  );
}
