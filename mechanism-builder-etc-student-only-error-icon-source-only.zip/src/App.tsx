import { useEffect, useMemo, useRef, useState } from 'react';
import type { ChangeEvent } from 'react';
import { toPng } from 'html-to-image';
import { ModelCanvas } from './components/ModelCanvas';
import { Field } from './components/Field';
import { Button, Card } from './components/UI';
import { type Connector, type PathwayTemplate, type PlacedPart } from './data/model';
import { assignmentTemplates } from './assignments/registry';
import { buildExampleModel, isFilled } from './lib/utils';
import { evaluateModel } from './lib/checker';
import { loadAssignmentState, saveAssignmentState } from './lib/persistence';



function downloadTextFile(filename: string, content: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function escapeHtml(value: string) {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}


function downloadJson(filename: string, data: unknown) {
  downloadTextFile(filename, JSON.stringify(data, null, 2), 'application/json;charset=utf-8');
}


type ImportedState = {
  currentScreen?: number;
  answers?: Record<string, unknown>;
  placedParts?: PlacedPart[];
  connectors?: Connector[];
};

function getConfiguredAnchors(template: PathwayTemplate, partId: string, flowType: Connector['type']) {
  return template.features?.customAnchors?.[partId]?.[flowType] ?? [];
}

function inferAnchorName(template: PathwayTemplate, partId: string, flowType: Connector['type'], role: 'from' | 'to') {
  const anchors = getConfiguredAnchors(template, partId, flowType);
  if (!anchors.length) return undefined;
  const outputPattern = flowType === 'electronFlow'
    ? /out$/i
    : flowType === 'protonFlow'
      ? /protonOut$/i
      : /(transitionOut|atpOut)$/i;
  const inputPattern = flowType === 'electronFlow'
    ? /(electronIn|transitionIn)$/i
    : flowType === 'protonFlow'
      ? /protonIn$/i
      : /transitionIn$/i;
  const preferred = anchors.find((anchor) => (role === 'from' ? outputPattern : inputPattern).test(anchor.name));
  return preferred?.name ?? anchors[0]?.name;
}

function inferAnchorsForConnector(template: PathwayTemplate, fromPart: PlacedPart | undefined, toPart: PlacedPart | undefined, connector: Connector) {
  const fallback = {
    fromAnchorName: connector.fromAnchorName ?? (fromPart ? inferAnchorName(template, fromPart.id, connector.type, 'from') : undefined),
    toAnchorName: connector.toAnchorName ?? (toPart ? inferAnchorName(template, toPart.id, connector.type, 'to') : undefined),
  };
  if (!fromPart || !toPart) return fallback;

  if (template.id === 'mitochondria' || template.id === 'mitochondria-mdma-ucp3') {
    const key = `${fromPart.id}->${toPart.id}`;
    const mapped: Record<string, { fromAnchorName: string; toAnchorName: string }> = {
      'nadh->complex-i': { fromAnchorName: 'electronOut', toAnchorName: 'electronIn' },
      'fadh2->complex-ii-q': { fromAnchorName: 'electronOut', toAnchorName: 'electronIn' },
      'complex-i->complex-ii-q': { fromAnchorName: 'electronOut', toAnchorName: 'electronIn' },
      'complex-ii-q->complex-iii': { fromAnchorName: 'electronOut', toAnchorName: 'electronIn' },
      'complex-iii->cytochrome-c': { fromAnchorName: 'electronOut', toAnchorName: 'electronIn' },
      'cytochrome-c->complex-iv': { fromAnchorName: 'electronOut', toAnchorName: 'electronIn' },
      'complex-iv->oxygen-water': { fromAnchorName: 'oxygenOut', toAnchorName: 'electronIn' },
      'low-protons->complex-i': { fromAnchorName: 'protonBottomPool', toAnchorName: 'protonBottomIntake' },
      'low-protons->complex-iii': { fromAnchorName: 'protonBottomPool', toAnchorName: 'protonBottomIntake' },
      'low-protons->complex-iv': { fromAnchorName: 'protonBottomPool', toAnchorName: 'protonBottomIntake' },
      'complex-i->protons': { fromAnchorName: 'protonTopPump', toAnchorName: 'protonTopPool' },
      'complex-iii->protons': { fromAnchorName: 'protonTopPump', toAnchorName: 'protonTopPool' },
      'complex-iv->protons': { fromAnchorName: 'protonTopPump', toAnchorName: 'protonTopPool' },
      'protons->atp-synthase': { fromAnchorName: 'protonTopPool', toAnchorName: 'protonTopIntake' },
      'atp-synthase->low-protons': { fromAnchorName: 'protonBottomExit', toAnchorName: 'protonBottomPool' },
      'protons->ucp3': { fromAnchorName: 'protonTopPool', toAnchorName: 'protonTopIntake' },
      'ucp3->low-protons': { fromAnchorName: 'protonBottomExit', toAnchorName: 'protonBottomPool' },
      'atp-synthase->adppi': { fromAnchorName: 'atpOut', toAnchorName: 'transitionIn' },
      'mdma->ucp3': { fromAnchorName: 'transitionOut', toAnchorName: 'transitionIn' },
    };
    if (mapped[key]) return { ...fallback, ...mapped[key] };
  }

  return fallback;
}

function normalizeConnectors(template: PathwayTemplate, placedParts: PlacedPart[], rawConnectors: Connector[]) {
  const partByUid = new Map(placedParts.map((part) => [part.uid, part]));
  return rawConnectors.map((connector) => {
    const fromPart = partByUid.get(connector.from);
    const toPart = partByUid.get(connector.to);
    return {
      ...connector,
      ...inferAnchorsForConnector(template, fromPart, toPart, connector),
    };
  });
}

function normalizeImportedState(template: PathwayTemplate, parsed: ImportedState) {
  const placedParts = Array.isArray(parsed.placedParts) ? parsed.placedParts : [];
  const connectors = Array.isArray(parsed.connectors) ? normalizeConnectors(template, placedParts, parsed.connectors) : [];
  return {
    currentScreen: typeof parsed.currentScreen === 'number' ? parsed.currentScreen : 0,
    answers: parsed.answers && typeof parsed.answers === 'object' ? parsed.answers : {},
    placedParts,
    connectors,
  };
}
export default function App() {
  const templateId = assignmentTemplates[0].id;
  const template = assignmentTemplates[0] as PathwayTemplate;
  const screens = template.screens;

  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState<Record<string, unknown>>({});
  const [placedParts, setPlacedParts] = useState<PlacedPart[]>([]);
  const [connectors, setConnectors] = useState<Connector[]>([]);
  const [showAssignment, setShowAssignment] = useState(false);
  const [lastSavedAt, setLastSavedAt] = useState('');
  const submissionCanvasRef = useRef<HTMLDivElement | null>(null);
  const importJsonInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    const saved = loadAssignmentState(templateId);
    if (saved) {
      const maxScreenIndex = Math.max(0, Math.min(saved.current, screens.length - 1));
      setCurrent(maxScreenIndex);
      const normalized = normalizeImportedState(template, { currentScreen: saved.current, answers: saved.answers, placedParts: saved.placedParts, connectors: saved.connectors });
      setAnswers(normalized.answers);
      setPlacedParts(normalized.placedParts);
      setConnectors(normalized.connectors);
      setShowAssignment(saved.showAssignment);
      setLastSavedAt(saved.savedAt);
      return;
    }

    setCurrent(0);
    setAnswers({});
    setPlacedParts([]);
    setConnectors([]);
    setShowAssignment(false);
    setLastSavedAt('');
  }, [templateId, screens.length]);

  useEffect(() => {
    const savedAt = saveAssignmentState(templateId, {
      current,
      answers,
      placedParts,
      connectors,
      showAssignment,
    });

    if (savedAt) setLastSavedAt(savedAt);
  }, [templateId, current, answers, placedParts, connectors, showAssignment]);

  const currentScreen = screens[current];
  const completedCount = useMemo(() => screens.filter((screen) => screen.fields.every((field) => isFilled(field, answers[field.key]))).length, [answers, screens]);
  const isLastScreen = current === screens.length - 1;
  const futureStages = template.features?.futureStages ?? [];

  const validationMessage = useMemo(() => '', []);
  const isDevMode = false;
  const liveCheckResult = useMemo(() => evaluateModel(template, placedParts, connectors), [template, placedParts, connectors]);
  const canGenerateSubmission = completedCount === screens.length && liveCheckResult.outputsMissing.length === 0;

  const canAdvance = currentScreen.fields.every((field) => isFilled(field, answers[field.key])) && !validationMessage;
  const handleChange = (key: string, value: unknown) => setAnswers((prev) => ({ ...prev, [key]: value }));
  const screenLabel = `Screen ${current + 1}`;
  const autosaveLabel = lastSavedAt ? `Autosaved locally · ${new Date(lastSavedAt).toLocaleString()}` : 'Autosave ready';
  const title = currentScreen.title.replace(/^Screen\s\d+\s—\s/, '');
  const applyExamplePreset = () => {
    const example = buildExampleModel(template);
    setPlacedParts(example.placedParts);
    setConnectors(normalizeConnectors(template, example.placedParts, example.connectors));
    if (template.exampleAnswers) {
      setAnswers((prev) => ({ ...prev, ...template.exampleAnswers }));
    }
  };

  const handleExportJson = () => {
    const payload = {
      assignmentId: template.id,
      assignmentName: template.name,
      exportedAt: new Date().toISOString(),
      currentScreen: current,
      answers,
      placedParts,
      connectors,
    };
    downloadJson(`${template.id}-state.json`, payload);
  };

  const handleImportJsonClick = () => {
    importJsonInputRef.current?.click();
  };

  const handleImportJson = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const raw = await file.text();
      const parsed = JSON.parse(raw);
      const normalized = normalizeImportedState(template, parsed);
      setCurrent(normalized.currentScreen);
      setAnswers(normalized.answers);
      setPlacedParts(normalized.placedParts);
      setConnectors(normalized.connectors);
    } catch (error) {
      console.error('Failed to import JSON state:', error);
      window.alert('That JSON file could not be loaded.');
    } finally {
      event.target.value = '';
    }
  };

  const handleGenerateSubmission = async () => {
    const checkResult = evaluateModel(template, placedParts, connectors);
    const timestamp = new Date().toISOString();

    let canvasImage = '';
    if (submissionCanvasRef.current) {
      try {
        canvasImage = await toPng(submissionCanvasRef.current, {
          cacheBust: true,
          pixelRatio: 2,
          backgroundColor: '#f3d8b3',
        });
      } catch (err) {
        console.error('Canvas image capture failed:', err);
      }
    }

    const screenAnswerRows = screens.flatMap((screen) =>
      screen.fields.map((field) => ({
        screen: screen.title,
        field: field.label,
        key: field.key,
        value: answers[field.key] ?? '',
      }))
    );

    const submissionData = {
      submissionVersion: 2,
      template: { id: template.id, name: template.name, subtitle: template.subtitle },
      generatedAt: timestamp,
      completion: { completedScreens: completedCount, totalScreens: screens.length, currentScreen: currentScreen.title },
      checker: checkResult,
      answers,
      answerRows: screenAnswerRows,
      placedParts: placedParts.map((part) => ({
        uid: part.uid, id: part.id, label: part.label, kind: part.kind, x: Math.round(part.x), y: Math.round(part.y), zone: part.zone,
      })),
      connectors: connectors.map((connector) => ({
        id: connector.id, from: connector.from, to: connector.to, type: connector.type, label: connector.label, color: connector.color, curveOffset: connector.curveOffset ?? 0,
      })),
      hasCanvasImage: Boolean(canvasImage),
    };

    const statusColor = checkResult.overallStatus === 'success' ? '#1f6f43' : checkResult.overallStatus === 'partial' ? '#8a5a10' : '#8b2f2f';
    const answersHtml = screenAnswerRows
      .map((row) => `<tr><td>${escapeHtml(row.screen)}</td><td>${escapeHtml(row.field)}</td><td>${escapeHtml(typeof row.value === 'string' ? row.value : JSON.stringify(row.value))}</td></tr>`)
      .join('');

    const partsHtml = submissionData.placedParts
      .map((part) => `<tr><td>${escapeHtml(part.label)}</td><td>${escapeHtml(part.kind)}</td><td>${part.x}</td><td>${part.y}</td><td>${escapeHtml(part.zone)}</td></tr>`)
      .join('');

    const connectorsHtml = connectors
      .map((connector) => {
        const fromPart = placedParts.find((part) => part.uid === connector.from);
        const toPart = placedParts.find((part) => part.uid === connector.to);
        return `<tr><td>${escapeHtml(fromPart?.label ?? connector.from)}</td><td>${escapeHtml(toPart?.label ?? connector.to)}</td><td>${escapeHtml(connector.type)}</td><td>${escapeHtml(connector.label)}</td></tr>`;
      })
      .join('');

    const listItems = (items: string[]) => items.length ? `<ul>${items.map((item) => `<li>${escapeHtml(item)}</li>`).join('')}</ul>` : '<p>None</p>';
    const activatedPathsHtml = checkResult.activatedPaths.length
      ? `<ul>${checkResult.activatedPaths.map((path) => `<li><strong>${escapeHtml(path.id)}</strong>: ${escapeHtml(path.description)}</li>`).join('')}</ul>`
      : '<p>None</p>';
    const blockedPathsHtml = checkResult.blockedPaths.length
      ? `<ul>${checkResult.blockedPaths.map((path) => `<li><strong>${escapeHtml(path.id)}</strong>: ${escapeHtml(path.reason)}</li>`).join('')}</ul>`
      : '<p>None</p>';

    const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${escapeHtml(template.name)} submission</title>
  <style>
    body { font-family: Arial, Helvetica, sans-serif; margin: 24px; color: #2f2218; background: #fbf6ef; }
    h1, h2, h3 { color: #7a4322; }
    .meta, .panel { background: #fff; border: 1px solid #d8c1a5; border-radius: 12px; padding: 16px; margin-bottom: 16px; }
    .status { color: ${statusColor}; font-weight: 700; }
    table { width: 100%; border-collapse: collapse; margin-top: 8px; }
    th, td { border: 1px solid #d8c1a5; padding: 8px; vertical-align: top; text-align: left; }
    th { background: #f4e4d1; }
    .small { color: #6b5a49; font-size: 0.92rem; }
    .canvas-shot { max-width: 100%; border: 1px solid #d8c1a5; border-radius: 12px; display: block; margin-top: 12px; }
  </style>
</head>
<body>
  <h1>${escapeHtml(template.name)} submission report</h1>
  <div class="meta">
    <p><strong>Generated:</strong> ${escapeHtml(timestamp)}</p>
    <p><strong>Current screen:</strong> ${escapeHtml(currentScreen.title)}</p>
    <p><strong>Completed screens:</strong> ${completedCount} / ${screens.length}</p>
    <p><strong>Checker status:</strong> <span class="status">${escapeHtml(checkResult.overallStatus)}</span></p>
    <p class="small">This file was generated by the assignment app for upload to Canvas.</p>
  </div>

  <div class="panel">
    <h2>Canvas image</h2>
    ${canvasImage ? `<img class="canvas-shot" src="${canvasImage}" alt="Student canvas submission image" />` : `<p>No canvas image was captured.</p>`}
  </div>

  <div class="panel">
    <h2>Checker summary</h2>
    <h3>Outputs produced</h3>
    ${listItems(checkResult.outputsProduced)}
    <h3>Outputs missing</h3>
    ${listItems(checkResult.outputsMissing)}
    <h3>Placement warnings</h3>
    ${listItems(checkResult.placementWarnings)}
    <h3>Required valid / working paths</h3>
    ${activatedPathsHtml}
    <h3>Blocked or biologically invalid paths</h3>
    ${blockedPathsHtml}
  </div>

  <div class="panel">
    <h2>Written responses</h2>
    <table><thead><tr><th>Screen</th><th>Prompt</th><th>Response</th></tr></thead><tbody>${answersHtml}</tbody></table>
  </div>

  <div class="panel">
    <h2>Placed parts</h2>
    <table><thead><tr><th>Part</th><th>Kind</th><th>X</th><th>Y</th><th>Zone</th></tr></thead><tbody>${partsHtml}</tbody></table>
  </div>

  <div class="panel">
    <h2>Arrows / connections</h2>
    <table><thead><tr><th>From</th><th>To</th><th>Type</th><th>Label</th></tr></thead><tbody>${connectorsHtml}</tbody></table>
  </div>

  <div class="panel">
    <h2>Embedded machine-readable submission data</h2>
    <p class="small">This section is included so the file can also be parsed automatically later if needed.</p>
    <pre>${escapeHtml(JSON.stringify(submissionData, null, 2))}</pre>
  </div>
  <script id="submission-data" type="application/json">${escapeHtml(JSON.stringify(submissionData))}</script>
</body>
</html>`;

    const slug = template.id.replace(/[^a-z0-9]+/gi, '-').toLowerCase();
    const stamp = timestamp.replace(/[:.]/g, '-');
    downloadTextFile(`${slug}-submission-${stamp}.html`, html, 'text/html;charset=utf-8');
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        background: 'linear-gradient(180deg, #eee1d1 0%, #dfc5a4 100%)',
        padding: '6px 4px 12px',
        fontFamily: 'Trebuchet MS, Arial, Helvetica, sans-serif',
        color: '#5f361b',
      }}
    >
      <Card
        style={{
          width: 'min(1840px, calc(100vw - 8px))',
          margin: '0 auto',
          padding: 8,
          borderRadius: 28,
          background: 'linear-gradient(180deg, #faedd9 0%, #f0d8b7 100%)',
          boxShadow: '0 18px 40px rgba(109, 67, 29, 0.14), inset 0 1px 0 rgba(255,255,255,0.84), inset 0 -1px 0 rgba(185,128,79,0.14)',
        }}
      >
        <input ref={importJsonInputRef} type="file" accept="application/json,.json" style={{ display: 'none' }} onChange={handleImportJson} />
        <div style={{ display: 'grid', gridTemplateColumns: '110px minmax(0, 1fr)', alignItems: 'center', gap: 10, padding: '2px 8px 6px', color: '#8a4f2a' }}>
          <div style={{ fontSize: 15, fontWeight: 700 }}>{screenLabel}</div>
          <div style={{ textAlign: 'center', display: 'grid', gap: 2 }}>
            <div style={{ fontSize: 13, color: '#a06a43', fontWeight: 700 }}>{template.name}</div>
            <div style={{ fontSize: 28, fontWeight: 700, color: '#8f4c28', letterSpacing: 0.2 }}>{title}</div>
            <div style={{ fontSize: 11, color: '#9a7452' }}>Use the palette to add parts, drag them into place, choose a flow button, then click one part and the next part to join them. Click the same flow button again to return to move mode. Double-click any part or arrow to delete it.</div>
          </div>
          <div style={{ display: 'grid', justifyItems: 'end', gap: 4 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ fontSize: 12, color: '#9a7452' }}>{completedCount}/{screens.length} complete</div>
            </div>
            <div style={{ fontSize: 11, color: '#a06a43' }}>{autosaveLabel}</div>
          </div>
        </div>

        <Card style={{ borderRadius: 20, marginBottom: 6, overflow: 'hidden' }}>
          <button
            onClick={() => setShowAssignment((prev) => !prev)}
            style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', border: 'none', background: 'transparent', padding: showAssignment ? '9px 12px' : '6px 10px', cursor: 'pointer', color: '#7a4322' }}
          >
            <div style={{ display: 'grid', gap: 2, textAlign: 'left' }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: '#9a6f46', textTransform: 'uppercase', letterSpacing: 0.5 }}>Assignment</div>
              <div style={{ fontSize: showAssignment ? 16 : 13, fontWeight: 700, lineHeight: 1.05 }}>{title}</div>
              <div style={{ fontSize: 11, color: '#9a7452' }}>{template.subtitle}</div>
            </div>
            <div style={{ fontSize: 11, fontWeight: 700 }}>{showAssignment ? 'Collapse ▲' : 'Expand ▼'}</div>
          </button>

          {showAssignment ? (
            <div style={{ padding: '0 16px 14px', display: 'grid', gap: 12 }}>
              <div style={{ marginTop: 2, height: 1, background: '#dfbf98' }} />
              {futureStages.length ? (
                <div style={{ display: 'grid', gap: 8 }}>
                  <div style={{ fontSize: 12, color: '#8a6340', fontWeight: 700 }}>Assignment stages</div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                    {screens.map((screen, index) => {
                      const done = screen.fields.every((field) => isFilled(field, answers[field.key]));
                      const active = index === current;
                      return (
                        <div key={screen.id} style={{ padding: '7px 10px', borderRadius: 999, border: active ? '1px solid #9d6035' : '1px solid #d6b28c', background: active ? '#f6dfbc' : done ? '#f3eadb' : '#fbf4e8', color: '#704528', fontSize: 12, fontWeight: 700 }}>
                          {screen.title.replace(/^Screen\s\d+\s—\s/, '')}
                        </div>
                      );
                    })}
                    {futureStages.map((label: string) => (
                      <div key={label} style={{ padding: '7px 10px', borderRadius: 999, border: '1px solid #d9d0c4', background: '#eee7dd', color: '#9a9289', fontSize: 12, fontWeight: 700 }}>
                        {label.replace(/^Screen\s\d+\s—\s/, '')}
                      </div>
                    ))}
                  </div>
                </div>
              ) : null}

              <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 10, alignItems: 'end' }}>
                <div style={{ fontSize: 15, lineHeight: 1.45, color: '#7b5636' }}>{currentScreen.description}</div>
              </div>

              <div style={{ display: 'grid', gap: 6, color: '#704528' }}>
                {currentScreen.tasks.map((task) => (
                  <div key={task} style={{ display: 'flex', gap: 8, fontSize: 14, lineHeight: 1.35 }}>
                    <span style={{ color: '#8e5e37' }}>→</span>
                    <span>{task}</span>
                  </div>
                ))}
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 10 }}>
                {currentScreen.fields.map((field) => <Field key={field.key} field={field} value={answers[field.key]} onChange={handleChange} />)}
              </div>

              {validationMessage ? <div style={{ display: 'flex', gap: 10, border: '1px solid #e59c8e', background: '#fae6e1', color: '#8b3124', borderRadius: 18, padding: 12, fontSize: 13 }}><span>⚠</span><span>{validationMessage}</span></div> : null}

              <div style={{ display: 'grid', gridTemplateColumns: '1fr minmax(220px, 300px)', gap: 10, alignItems: 'end' }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                  <Button onClick={() => setCurrent((prev) => Math.max(prev - 1, 0))} disabled={current === 0}>Back</Button>
                  <Button primary onClick={() => setCurrent((prev) => Math.min(prev + 1, screens.length - 1))} disabled={!canAdvance || current === screens.length - 1}>Next</Button>
                </div>
                <div style={{ display: 'grid', gap: 6 }}>
                  <div style={{ fontSize: 12, color: '#8a6340' }}>Jump to screen</div>
                  <select
                    value={current}
                    onChange={(e) => setCurrent(Number(e.target.value))}
                    style={{ width: '100%', borderRadius: 16, border: '1px solid #d6ae84', padding: '10px 13px', fontSize: 14, background: 'linear-gradient(180deg, #fff6e9 0%, #f4dfc1 100%)', color: '#5f361b', boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.7)' }}
                  >
                    {screens.map((screen, index) => <option key={screen.id} value={index}>{screen.title}</option>)}
                  </select>
                </div>
              </div>

              {isLastScreen ? (
                <div style={{ marginTop: 16, display: 'flex', justifyContent: 'flex-end' }}>
                  <Button primary onClick={handleGenerateSubmission}>Generate submission file</Button>
                </div>
              ) : null}
            </div>
          ) : null}
        </Card>

        {!showAssignment ? (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 10, padding: '0 4px 6px' }}>
            <div style={{ fontSize: 12, color: '#8a6340', alignSelf: 'center' }}>{template.name} · {template.subtitle}</div>
          </div>
        ) : null}

        <div style={{ border: '1px solid #d5a97e', borderRadius: 24, background: 'linear-gradient(180deg, rgba(249,236,216,0.98) 0%, rgba(241,216,178,0.95) 100%)', overflow: 'hidden', boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.62), 0 10px 24px rgba(139,95,52,0.08)' }}>
          <ModelCanvas canvasCaptureRef={submissionCanvasRef} template={template} placedParts={placedParts} setPlacedParts={setPlacedParts} currentScreenId={currentScreen.id} connectors={connectors} setConnectors={setConnectors} setAnswers={setAnswers} />
          {isLastScreen ? (
            <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '6px 6px 2px' }}>
              <div style={{ display: 'grid', gap: 4, justifyItems: 'end' }}>
                <Button primary onClick={handleGenerateSubmission}>Generate submission file</Button>
              </div>
            </div>
          ) : null}
        </div>
      </Card>
    </div>
  );
}
