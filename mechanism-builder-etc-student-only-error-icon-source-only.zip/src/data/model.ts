export type {
  FieldDef,
  ScreenDef,
  PartKind,
  Zone,
  LayoutMode,
  PartDef,
  PlacedPart,
  ConnectorType,
  Connector,
  Pointer,
  DragState,
  PathwayTemplate,
} from '../assignments/types';

import type { PartKind } from '../assignments/types';
import { assignmentTemplates } from '../assignments/registry';

export const defaultTemplate = assignmentTemplates[0];
export const CANVAS_WIDTH = defaultTemplate.canvasWidth;
export const CANVAS_HEIGHT = defaultTemplate.canvasHeight;
export const PART_WIDTH = 72;
export const PART_HEIGHT = 82;

export function getPartDimensions(kind: PartKind) {
  switch (kind) {
    case 'complexI':
    case 'complexII':
    case 'complexIIQ':
    case 'complexIII':
    case 'complexIV':
      return { width: 123, height: 123 };
    case 'atpSynthase':
      return { width: 123, height: 123 };
    case 'ucp':
      return { width: 123, height: 123 };
    case 'coenzymeQ':
      return { width: 70, height: 70 };
    case 'cytochromeC':
      return { width: 190, height: 62 };
    case 'oxygenWater':
      return { width: 168, height: 74 };
    case 'atpCycle':
      return { width: 176, height: 76 };
    case 'protons':
      return { width: 78, height: 70 };
    case 'oxygen':
    case 'water':
    case 'signal':
    case 'heat':
    case 'atp':
      return { width: 70, height: 70 };
    case 'host':
      return { width: 120, height: 78 };
    case 'stage':
      return { width: 116, height: 74 };
    case 'spore':
      return { width: 84, height: 84 };
    default:
      return { width: PART_WIDTH, height: PART_HEIGHT };
  }
}

export function getPartHitboxDimensions(kind: PartKind) {
  switch (kind) {
    case 'complexI':
      return { width: 62, height: 92, offsetX: 30, offsetY: 16 };
    case 'complexII':
      return { width: 60, height: 88, offsetX: 31, offsetY: 18 };
    case 'complexIIQ':
      return { width: 68, height: 92, offsetX: 28, offsetY: 15 };
    case 'complexIII':
      return { width: 72, height: 92, offsetX: 26, offsetY: 16 };
    case 'complexIV':
      return { width: 74, height: 88, offsetX: 25, offsetY: 18 };
    case 'atpSynthase':
      return { width: 66, height: 104, offsetX: 29, offsetY: 10 };
    case 'ucp':
      return { width: 48, height: 92, offsetX: 38, offsetY: 16 };
    case 'cytochromeC':
      return { width: 146, height: 34, offsetX: 22, offsetY: 14 };
    case 'oxygenWater':
      return { width: 136, height: 42, offsetX: 16, offsetY: 16 };
    case 'atpCycle':
      return { width: 144, height: 42, offsetX: 16, offsetY: 18 };
    case 'protons':
      return { width: 60, height: 44, offsetX: 9, offsetY: 14 };
    default:
      const dims = getPartDimensions(kind);
      return { width: dims.width, height: dims.height, offsetX: 0, offsetY: 0 };
  }
}
