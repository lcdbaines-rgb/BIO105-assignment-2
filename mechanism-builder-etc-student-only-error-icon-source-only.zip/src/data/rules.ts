export type {
  FlowTypeRule,
  FlowPortRule,
  PartRule,
  ConnectionRule,
  LogicRule,
  PathwayRuleSchema,
  ActivatedPath,
  BlockedPath,
  CheckResult,
} from '../assignments/types';

import type { PathwayTemplate, PathwayRuleSchema } from '../assignments/types';
import { assignmentSchemas } from '../assignments/registry';

export function getSchemaForTemplate(template: PathwayTemplate): PathwayRuleSchema | null {
  return assignmentSchemas[template.id as keyof typeof assignmentSchemas] ?? null;
}
