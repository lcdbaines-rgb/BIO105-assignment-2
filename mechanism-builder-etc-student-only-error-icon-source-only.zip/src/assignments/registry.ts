import type { PathwayTemplate } from './types';
import { etcNormalSystemSchema } from './etc-normal-system/rules';
import { etcNormalSystemTemplate } from './etc-normal-system/config';

export const assignmentRegistry: Record<string, PathwayTemplate> = {
  [etcNormalSystemTemplate.id]: etcNormalSystemTemplate,
};

export const assignmentTemplates = [etcNormalSystemTemplate];

export const assignmentSchemas = {
  [etcNormalSystemSchema.templateId]: etcNormalSystemSchema,
};
