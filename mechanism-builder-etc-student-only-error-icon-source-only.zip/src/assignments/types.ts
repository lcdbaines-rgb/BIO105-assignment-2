export type FieldDef = {
  key: string;
  label: string;
  type: 'select' | 'checkbox' | 'textarea';
  options?: string[];
};

export type ScreenDef = {
  id: string;
  title: string;
  description: string;
  tasks: string[];
  fields: FieldDef[];
};

export type PartKind =
  | 'complexI'
  | 'complexII'
  | 'complexIIQ'
  | 'complexIII'
  | 'complexIV'
  | 'coenzymeQ'
  | 'cytochromeC'
  | 'protons'
  | 'atpSynthase'
  | 'ucp'
  | 'signal'
  | 'heat'
  | 'atp'
  | 'oxygen'
  | 'water'
  | 'oxygenWater'
  | 'atpCycle'
  | 'stage'
  | 'host'
  | 'spore';

export type Zone = 'top' | 'membrane' | 'bottom' | 'left' | 'center' | 'right';
export type LayoutMode = 'membrane' | 'lifecycle';

export type PartDef = {
  id: string;
  label: string;
  kind: PartKind;
  defaultZone: Zone;
};

export type PlacedPart = PartDef & {
  uid: string;
  x: number;
  y: number;
  zone: Zone;
};

export type ConnectorType = 'electronFlow' | 'protonFlow' | 'transition';

export type Connector = {
  id: string;
  from: string;
  to: string;
  label: string;
  color: string;
  type: ConnectorType;
  curveOffset?: number;
  fromAnchorName?: string;
  toAnchorName?: string;
};

export type Pointer = { x: number; y: number };

export type DragState = {
  uid: string;
  offsetX: number;
  offsetY: number;
};


export type AnchorPointDef = {
  name: string;
  x: number;
  y: number;
};

export type AssignmentAnchorConfig = Partial<Record<ConnectorType, AnchorPointDef[]>>;
export type AssignmentAnchorMap = Record<string, AssignmentAnchorConfig>;

export type ExampleModelResult = {
  placedParts: PlacedPart[];
  connectors: Connector[];
};

export type ExampleModelBuilder = (template: PathwayTemplate) => ExampleModelResult;

export type AssignmentFeatures = {
  futureStages?: string[];
  lockedPartIds?: string[];
  anchorSet?: 'generic' | 'assignment';
  customAnchors?: AssignmentAnchorMap;
  exampleModelBuilder?: ExampleModelBuilder;
  checkerStyle?: 'lifecycle' | 'mitochondria' | 'photosynthesis';
  normalOnlyMode?: boolean;
};

export type PathwayTemplate = {
  id: string;
  name: string;
  subtitle: string;
  layoutMode: LayoutMode;
  canvasWidth: number;
  canvasHeight: number;
  promptByScreen: Record<string, string>;
  screens: ScreenDef[];
  parts: PartDef[];
  exampleAnswers?: Record<string, unknown>;
  connectorOptions: Array<{
    id: ConnectorType;
    label: string;
    short: string;
    color: string;
  }>;
  features?: AssignmentFeatures;
};

export type FlowTypeRule = {
  id: ConnectorType;
  label: string;
  animated: boolean;
  color: string;
};

export type FlowPortRule = {
  flowType: ConnectorType;
  direction: 'in' | 'out';
  partnerPartIds?: string[];
  required?: boolean;
};

export type PartRule = {
  id: string;
  label: string;
  preferredZones: Zone[];
  receives?: FlowPortRule[];
  emits?: FlowPortRule[];
  tags?: string[];
};

export type ConnectionRule = {
  flowType: ConnectorType;
  sourcePartId: string;
  targetPartId: string;
  required?: boolean;
  description: string;
};

export type LogicRule = {
  id: string;
  requiredConnectionKeys?: string[];
  requiredParts?: string[];
  producedOutputs: string[];
  description: string;
};

export type PathwayRuleSchema = {
  templateId: string;
  parts: PartRule[];
  flows: FlowTypeRule[];
  requiredConnections: ConnectionRule[];
  logicRules: LogicRule[];
};

export type ActivatedPath = {
  id: string;
  flowType: ConnectorType;
  sequence: string[];
  connectorIds: string[];
  description: string;
};

export type BlockedPath = {
  id: string;
  flowType: ConnectorType | 'mixed';
  attemptedSequence: string[];
  connectorIds: string[];
  brokeAt?: string;
  reason: string;
};

export type CheckResult = {
  overallStatus: 'success' | 'partial' | 'broken';
  activeConnectorIds: string[];
  blockedConnectorIds: string[];
  activePartUids: string[];
  blockedPartUids: string[];
  outputsProduced: string[];
  outputsMissing: string[];
  placementWarnings: string[];
  activatedPaths: ActivatedPath[];
  blockedPaths: BlockedPath[];
};
