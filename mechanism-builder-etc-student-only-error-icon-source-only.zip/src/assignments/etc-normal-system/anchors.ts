import type { AssignmentAnchorMap } from '../types';

export const etcNormalSystemAnchors: AssignmentAnchorMap = {
  nadh: {
    electronFlow: [{ name: 'electronOut', x: 0.8, y: 0.38 }],
    transition: [{ name: 'out', x: 0.8, y: 0.38 }],
  },
  fadh2: {
    electronFlow: [{ name: 'electronOut', x: 0.82, y: 0.38 }],
    transition: [{ name: 'out', x: 0.82, y: 0.38 }],
  },
  'complex-i': {
    electronFlow: [
      { name: 'electronOut', x: 0.9, y: 0.56 },
      { name: 'electronIn', x: 0.14, y: 0.72 },
    ],
    protonFlow: [
      { name: 'protonTopPump', x: 0.48, y: 0.13 },
      { name: 'protonBottomIntake', x: 0.5, y: 0.9 },
    ],
  },
  'complex-ii-q': {
    electronFlow: [
      { name: 'electronIn', x: 0.2, y: 0.64 },
      { name: 'electronOut', x: 0.77, y: 0.42 },
    ],
  },
  'complex-iii': {
    electronFlow: [
      { name: 'electronIn', x: 0.07, y: 0.42 },
      { name: 'electronOut', x: 0.88, y: 0.46 },
    ],
    protonFlow: [
      { name: 'protonTopPump', x: 0.5, y: 0.12 },
      { name: 'protonBottomIntake', x: 0.5, y: 0.9 },
    ],
  },
  'cytochrome-c': {
    electronFlow: [
      { name: 'electronIn', x: 0.2, y: 0.5 },
      { name: 'electronOut', x: 0.8, y: 0.5 },
    ],
  },
  'complex-iv': {
    electronFlow: [
      { name: 'electronIn', x: 0.1, y: 0.56 },
      { name: 'oxygenOut', x: 0.82, y: 0.44 },
    ],
    protonFlow: [
      { name: 'protonTopPump', x: 0.48, y: 0.12 },
      { name: 'protonBottomIntake', x: 0.5, y: 0.9 },
    ],
    transition: [{ name: 'transitionOut', x: 0.82, y: 0.44 }],
  },
  'oxygen-water': {
    electronFlow: [{ name: 'electronIn', x: 0.16, y: 0.58 }],
    transition: [{ name: 'transitionIn', x: 0.16, y: 0.58 }],
  },
  protons: {
    protonFlow: [{ name: 'protonTopPool', x: 0.5, y: 0.78 }],
  },
  'low-protons': {
    protonFlow: [{ name: 'protonBottomPool', x: 0.5, y: 0.22 }],
  },
  'atp-synthase': {
    protonFlow: [
      { name: 'protonTopIntake', x: 0.5, y: 0.1 },
      { name: 'protonBottomExit', x: 0.58, y: 0.9 },
    ],
    transition: [{ name: 'atpOut', x: 0.82, y: 0.78 }],
  },
  adppi: {
    transition: [{ name: 'transitionIn', x: 0.2, y: 0.36 }],
  },
  ucp3: {
    protonFlow: [
      { name: 'protonTopIntake', x: 0.5, y: 0.1 },
      { name: 'protonBottomExit', x: 0.5, y: 0.9 },
    ],
  },
  ucp1: {
    protonFlow: [
      { name: 'protonTopIntake', x: 0.5, y: 0.1 },
      { name: 'protonBottomExit', x: 0.5, y: 0.9 },
    ],
  },
  mdma: {
    transition: [{ name: 'transitionOut', x: 0.5, y: 0.82 }],
  },
  heat: {
    transition: [{ name: 'transitionIn', x: 0.18, y: 0.5 }],
  },
};
