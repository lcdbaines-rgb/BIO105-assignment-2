import type { ConnectorType, PartDef } from '../types';

export const mitochondriaParts: PartDef[] = [
  { id: 'nadh', label: 'NADH', kind: 'signal', defaultZone: 'bottom' },
  { id: 'fadh2', label: 'FADH2', kind: 'signal', defaultZone: 'bottom' },
  { id: 'complex-i', label: 'Complex I', kind: 'complexI', defaultZone: 'membrane' },
  { id: 'complex-ii-q', label: 'Complex II + Q', kind: 'complexIIQ', defaultZone: 'membrane' },
  { id: 'complex-iii', label: 'Complex III', kind: 'complexIII', defaultZone: 'membrane' },
  { id: 'cytochrome-c', label: 'Cytochrome c', kind: 'cytochromeC', defaultZone: 'top' },
  { id: 'complex-iv', label: 'Complex IV', kind: 'complexIV', defaultZone: 'membrane' },
  { id: 'oxygen-water', label: 'O₂ → H₂O', kind: 'oxygenWater', defaultZone: 'top' },
  { id: 'protons', label: 'High H⁺', kind: 'protons', defaultZone: 'top' },
  { id: 'low-protons', label: 'Low H⁺', kind: 'protons', defaultZone: 'bottom' },
  { id: 'atp-synthase', label: 'ATP synthase', kind: 'atpSynthase', defaultZone: 'membrane' },
  { id: 'adppi', label: 'ADP + Pi → ATP', kind: 'atpCycle', defaultZone: 'bottom' },
  { id: 'ucp3', label: 'UCP3', kind: 'ucp', defaultZone: 'membrane' },
  { id: 'ucp1', label: 'UCP1', kind: 'ucp', defaultZone: 'membrane' },
  { id: 'mdma', label: 'MDMA', kind: 'signal', defaultZone: 'top' },
  { id: 'heat', label: 'Heat', kind: 'heat', defaultZone: 'right' },
];

export const connectorOptions: Array<{ id: ConnectorType; label: string; short: string; color: string }> = [
  { id: 'electronFlow', label: 'Electron flow', short: 'e⁻', color: '#f0b323' },
  { id: 'protonFlow', label: 'Proton flow', short: 'H⁺', color: '#2e86de' },
  { id: 'transition', label: 'Output / signal', short: '→', color: '#222222' },
];
