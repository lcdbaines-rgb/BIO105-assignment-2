import type { ScreenDef } from '../types';

export const mitochondriaScreens: ScreenDef[] = [
  {
    id: 'start',
    title: 'Screen 1 — Start',
    description: 'Build the normal mitochondrial electron transport system. Later pathway steps are shown but locked for now.',
    tasks: ['Read the goal and canvas instructions', 'Confirm your assigned version', 'Acknowledge AI use rules'],
    fields: [
      { key: 'version', label: 'Assigned version', type: 'select', options: ['Normal system only'] },
      { key: 'aiAck', label: 'I understand that AI use must be stated and I remain responsible for my answers.', type: 'checkbox' },
    ],
  },
  {
    id: 'normal',
    title: 'Screen 2 — Build the Normal System',
    description: 'Construct normal mitochondrial respiration only. Later UCP3, MDMA, and comparison steps will be activated in a later assignment version.',
    tasks: [
      'Build the normal system on the canvas using the parts you need from the palette',
      'Drag parts into position, then use the flow buttons to connect one part to another',
      'Click the same flow button again to return to move mode, and double-click any part or arrow to delete it',
      'Use Check your work to see where the pathway breaks, then revise and try again',
    ],
    fields: [{ key: 'normalSummary', label: 'Describe how electron flow and proton movement lead to ATP production in the normal system', type: 'textarea' }],
  },
  {
    id: 'feedback',
    title: 'Screen 3 — App Feedback',
    description: 'Give feedback on how the app worked for you so the assignment can be improved.',
    tasks: ['Rate how easy the canvas was to use', 'Describe one thing that worked well', 'Describe one improvement that would help students'],
    fields: [
      { key: 'easeOfUse', label: 'How easy was the app to use?', type: 'select', options: ['Very easy', 'Mostly easy', 'Mixed', 'Mostly difficult', 'Very difficult'] },
      { key: 'workedWell', label: 'What worked well?', type: 'textarea' },
      { key: 'improveApp', label: 'What could be improved?', type: 'textarea' },
    ],
  },
];
