import type { PathwayTemplate } from '../types';
import { connectorOptions, mitochondriaParts } from './parts';
import { etcNormalSystemAnchors } from './anchors';
import { mitochondriaScreens } from './screens';
import { buildEtcNormalSystemExampleModel } from './presets';

export const etcNormalSystemTemplate: PathwayTemplate = {
  id: 'mitochondria',
  name: 'Mitochondrial mechanism builder',
  subtitle: 'Normal system student version',
  layoutMode: 'membrane',
  canvasWidth: 1480,
  canvasHeight: 360,
  promptByScreen: {
    start: 'Read the directions, note the locked later stages, and prepare to build only the normal ETC system.',
    normal: 'Build only the normal ETC with correct placement: NADH and FADH2 on the matrix side, Complexes I, II + Q, III, and IV in the inner membrane, cytochrome c between III and IV, O₂ → H₂O near Complex IV, high H⁺ in the intermembrane space, low H⁺ in the matrix, and ATP synthase using the proton gradient to support ATP production.',
    feedback: 'Complete the app feedback so your instructor can improve the assignment before later pathway stages are unlocked.',
  },
  screens: mitochondriaScreens,
  parts: mitochondriaParts,
  exampleAnswers: {
    version: 'Normal system only',
    aiAck: true,
    normalSummary: 'Electrons move from NADH and FADH2 through the inner-membrane complexes to Complex IV, where oxygen is reduced to water. Complexes I, III, and IV pump protons into the intermembrane space. Protons then return through ATP synthase, which helps drive ATP production.',
    easeOfUse: 'Mostly easy',
    workedWell: 'The drag-and-drop parts and animated arrows made it easier to see how the normal system fits together.',
    improveApp: 'It would help to have clearer endpoint snapping and a short tutorial the first time the canvas opens.',
  },
  connectorOptions,
  features: {
    futureStages: [
      'Screen 4 — UCP3 leak (locked)',
      'Screen 5 — MDMA effect (locked)',
      'Screen 6 — Zoom-in checkpoint (locked)',
      'Screen 7 — Revision (locked)',
      'Screen 8 — UCP1 comparison (locked)',
    ],
    lockedPartIds: ['ucp3', 'ucp1', 'mdma', 'heat'],
    anchorSet: 'assignment',
    customAnchors: etcNormalSystemAnchors,
    exampleModelBuilder: buildEtcNormalSystemExampleModel,
    checkerStyle: 'mitochondria',
    normalOnlyMode: true,
  },
};
