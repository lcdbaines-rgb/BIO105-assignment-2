import type { Connector, PartDef, PlacedPart, PathwayTemplate, Zone } from '../types';

type ExamplePlaced = { id: string; key?: string; x: number; y: number; zone: Zone };
type ExampleConnector = { from: string; to: string; type: Connector['type']; curveOffset?: number };

function createPlacedFromExample(part: PartDef, example: ExamplePlaced): PlacedPart {
  return {
    ...part,
    uid: `${part.id}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    x: example.x,
    y: example.y,
    zone: example.zone,
  };
}

export function buildEtcNormalSystemExampleModel(template: PathwayTemplate) {
  const examples: ExamplePlaced[] = [
    { key: 'nadh', id: 'nadh', x: 88, y: 264, zone: 'bottom' },
    { key: 'fadh2', id: 'fadh2', x: 178, y: 264, zone: 'bottom' },
    { key: 'complex-i', id: 'complex-i', x: 286, y: 124, zone: 'membrane' },
    { key: 'complex-ii-q', id: 'complex-ii-q', x: 452, y: 124, zone: 'membrane' },
    { key: 'complex-iii', id: 'complex-iii', x: 620, y: 124, zone: 'membrane' },
    { key: 'cytochrome-c', id: 'cytochrome-c', x: 764, y: 114, zone: 'top' },
    { key: 'complex-iv', id: 'complex-iv', x: 920, y: 124, zone: 'membrane' },
    { key: 'oxygen-water', id: 'oxygen-water', x: 1076, y: 96, zone: 'top' },
    { key: 'low-h1', id: 'low-protons', x: 304, y: 270, zone: 'bottom' },
    { key: 'low-h2', id: 'low-protons', x: 638, y: 270, zone: 'bottom' },
    { key: 'low-h3', id: 'low-protons', x: 938, y: 270, zone: 'bottom' },
    { key: 'low-h4', id: 'low-protons', x: 1168, y: 270, zone: 'bottom' },
    { key: 'low-h5', id: 'low-protons', x: 1328, y: 270, zone: 'bottom' },
    { key: 'high-h1', id: 'protons', x: 304, y: 24, zone: 'top' },
    { key: 'high-h2', id: 'protons', x: 638, y: 24, zone: 'top' },
    { key: 'high-h3', id: 'protons', x: 938, y: 24, zone: 'top' },
    { key: 'atp-synthase', id: 'atp-synthase', x: 1150, y: 124, zone: 'membrane' },
    { key: 'adppi', id: 'adppi', x: 1128, y: 272, zone: 'bottom' },
    { key: 'high-h4', id: 'protons', x: 1168, y: 24, zone: 'top' },
    { key: 'ucp3', id: 'ucp3', x: 1312, y: 124, zone: 'membrane' },
    { key: 'high-h5', id: 'protons', x: 1328, y: 24, zone: 'top' },
    { key: 'mdma', id: 'mdma', x: 1312, y: 42, zone: 'top' },
  ];
  const links: ExampleConnector[] = [
    { from: 'nadh', to: 'complex-i', type: 'electronFlow', curveOffset: 6 },
    { from: 'fadh2', to: 'complex-ii-q', type: 'electronFlow', curveOffset: 8 },
    { from: 'complex-i', to: 'complex-ii-q', type: 'electronFlow', curveOffset: 16 },
    { from: 'complex-ii-q', to: 'complex-iii', type: 'electronFlow', curveOffset: 18 },
    { from: 'complex-iii', to: 'cytochrome-c', type: 'electronFlow', curveOffset: -12 },
    { from: 'cytochrome-c', to: 'complex-iv', type: 'electronFlow', curveOffset: -16 },
    { from: 'complex-iv', to: 'oxygen-water', type: 'electronFlow', curveOffset: -22 },
    { from: 'low-h1', to: 'complex-i', type: 'protonFlow', curveOffset: 18 },
    { from: 'complex-i', to: 'high-h1', type: 'protonFlow', curveOffset: -12 },
    { from: 'low-h2', to: 'complex-iii', type: 'protonFlow', curveOffset: 18 },
    { from: 'complex-iii', to: 'high-h2', type: 'protonFlow', curveOffset: -12 },
    { from: 'low-h3', to: 'complex-iv', type: 'protonFlow', curveOffset: 18 },
    { from: 'complex-iv', to: 'high-h3', type: 'protonFlow', curveOffset: -12 },
    { from: 'high-h4', to: 'atp-synthase', type: 'protonFlow', curveOffset: -4 },
    { from: 'atp-synthase', to: 'low-h4', type: 'protonFlow', curveOffset: 8 },
    { from: 'atp-synthase', to: 'adppi', type: 'transition', curveOffset: 18 },
    { from: 'high-h5', to: 'ucp3', type: 'protonFlow', curveOffset: -4 },
    { from: 'ucp3', to: 'low-h5', type: 'protonFlow', curveOffset: 8 },
    { from: 'mdma', to: 'ucp3', type: 'transition' },
  ];

  const partsById = new Map(template.parts.map((part) => [part.id, part]));
  const placedParts = examples.map((example) => createPlacedFromExample(partsById.get(example.id)!, example));
  const uidByKey = new Map(placedParts.map((part, index) => [examples[index].key ?? examples[index].id, part.uid]));
  const connectors = links.flatMap((link, index) => {
    const from = uidByKey.get(link.from);
    const to = uidByKey.get(link.to);
    const option = template.connectorOptions.find((item) => item.id === link.type);
    if (!from || !to || !option) return [];
    return [{ id: `example-${index + 1}`, from, to, type: link.type, label: option.short, color: option.color, curveOffset: link.curveOffset ?? 0 }];
  });

  return { placedParts, connectors };
}
