import type { Connector, PathwayTemplate, PlacedPart } from '../types';

function placePart(template: PathwayTemplate, partId: string, x: number, y: number): PlacedPart {
  const part = template.parts.find((item) => item.id === partId);
  if (!part) throw new Error(`Missing part definition for ${partId}`);
  return {
    ...part,
    uid: `${partId}-${x}-${y}`,
    x,
    y,
    zone: part.defaultZone,
  };
}

function connector(from: PlacedPart, to: PlacedPart, type: Connector['type'], label: string, color: string, curveOffset = 0, fromAnchorName?: string, toAnchorName?: string): Connector {
  return {
    id: `${type}-${from.uid}-${to.uid}`,
    from: from.uid,
    to: to.uid,
    type,
    label,
    color,
    curveOffset,
    fromAnchorName,
    toAnchorName,
  };
}

export function buildPhotosynthesisExampleModel(template: PathwayTemplate) {
  const lightPSII = placePart(template, 'light-psii', 164, 18);
  const waterOxygen = placePart(template, 'water-oxygen', 58, 26);
  const psii = placePart(template, 'photosystem-ii', 220, 110);
  const pq = placePart(template, 'plastoquinone', 466, 110);
  const b6f = placePart(template, 'cytochrome-b6f', 704, 110);
  const pc = placePart(template, 'plastocyanin', 840, 46);
  const psi = placePart(template, 'photosystem-i', 1002, 110);
  const lightPSI = placePart(template, 'light-psi', 1068, 18);
  const nadph = placePart(template, 'nadph-output', 1160, 34);
  const highProtons = placePart(template, 'protons', 824, 20);
  const lowProtons = placePart(template, 'low-protons', 980, 262);
  const atpSynthase = placePart(template, 'atp-synthase', 1236, 112);
  const adpPi = placePart(template, 'adppi', 1268, 252);

  const placedParts = [lightPSII, waterOxygen, psii, pq, b6f, pc, psi, lightPSI, nadph, highProtons, lowProtons, atpSynthase, adpPi];

  const electron = '#f0b323';
  const proton = '#2e86de';
  const transition = '#222222';

  const connectors: Connector[] = [
    connector(lightPSII, psii, 'transition', 'Light → PSII', transition),
    connector(psii, waterOxygen, 'transition', 'PSII → H₂O → O₂', transition),
    connector(psii, pq, 'electronFlow', 'PSII → Plastoquinone', electron),
    connector(pq, b6f, 'electronFlow', 'Plastoquinone → Cytochrome b6f', electron),
    connector(b6f, pc, 'electronFlow', 'Cytochrome b6f → Plastocyanin', electron, -24),
    connector(pc, psi, 'electronFlow', 'Plastocyanin → PSI', electron, -18),
    connector(lightPSI, psi, 'transition', 'Light → PSI', transition),
    connector(psi, nadph, 'electronFlow', 'PSI → NADP⁺ → NADPH', electron),
    connector(lowProtons, b6f, 'protonFlow', 'Low H⁺ → Cytochrome b6f', proton),
    connector(b6f, highProtons, 'protonFlow', 'Cytochrome b6f → High H⁺', proton),
    connector(highProtons, atpSynthase, 'protonFlow', 'High H⁺ → ATP synthase', proton),
    connector(atpSynthase, lowProtons, 'protonFlow', 'ATP synthase → Low H⁺', proton),
    connector(atpSynthase, adpPi, 'transition', 'ATP synthase → ADP + Pi → ATP', transition),
  ];

  return { placedParts, connectors };
}
