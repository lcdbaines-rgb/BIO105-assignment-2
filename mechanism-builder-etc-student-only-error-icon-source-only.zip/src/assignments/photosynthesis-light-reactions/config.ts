import type { PathwayTemplate } from '../types';
import { photosynthesisAnchors } from './anchors';
import { photosynthesisParts, connectorOptions } from './parts';
import { buildPhotosynthesisExampleModel } from './presets';
import { photosynthesisScreens } from './screens';

export const photosynthesisLightReactionsTemplate: PathwayTemplate = {
  id: 'photosynthesis-light-reactions',
  name: 'Photosynthesis mechanism builder',
  subtitle: 'Light reactions across the thylakoid membrane',
  layoutMode: 'membrane',
  canvasWidth: 1480,
  canvasHeight: 360,
  promptByScreen: {
    start: 'Read the directions and prepare to model the light reactions of photosynthesis across the thylakoid membrane.',
    'light-reactions': 'Build Photosystem II, plastoquinone, cytochrome b6f, plastocyanin, Photosystem I, and the NADPH output step. Include light input at both photosystems and show water splitting at Photosystem II.',
    'atp-branch': 'Add the thylakoid proton gradient and ATP synthase so the model shows how ATP is produced from the lumen-to-stroma proton return.',
    feedback: 'Complete the app feedback so the photosynthesis assignment can be improved.',
  },
  screens: photosynthesisScreens,
  parts: photosynthesisParts,
  exampleAnswers: {
    version: 'Photosynthesis light reactions',
    aiAck: true,
    lightSummary: 'Light excites electrons at Photosystem II and again at Photosystem I. Water splitting at PSII helps replace electrons and releases oxygen. The electrons move through plastoquinone, cytochrome b6f, plastocyanin, and PSI before reducing NADP⁺ to NADPH.',
    atpSummary: 'Cytochrome b6f contributes to a proton gradient in the thylakoid lumen. Protons then move back through ATP synthase into the stroma, which helps drive ATP production.',
    easeOfUse: 'Mostly easy',
    workedWell: 'The staged layout made it easier to separate the light-driven electron chain from the ATP synthase branch.',
    improveApp: 'It would help to label the lumen and stroma more directly on the canvas.',
  },
  connectorOptions,
  features: {
    futureStages: ['Screen 5 — Calvin cycle link (locked)', 'Screen 6 — cyclic electron flow (locked)'],
    anchorSet: 'assignment',
    customAnchors: photosynthesisAnchors,
    exampleModelBuilder: buildPhotosynthesisExampleModel,
    checkerStyle: 'photosynthesis',
    normalOnlyMode: false,
  },
};
