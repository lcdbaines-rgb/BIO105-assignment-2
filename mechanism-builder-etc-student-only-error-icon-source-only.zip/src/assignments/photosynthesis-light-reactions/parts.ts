import type { ConnectorType, PartDef } from '../types';

export const photosynthesisParts: PartDef[] = [
  { id: 'light-psii', label: 'Light → PSII', kind: 'signal', defaultZone: 'top' },
  { id: 'water-oxygen', label: 'H₂O → O₂', kind: 'oxygenWater', defaultZone: 'top' },
  { id: 'photosystem-ii', label: 'Photosystem II', kind: 'complexI', defaultZone: 'membrane' },
  { id: 'plastoquinone', label: 'Plastoquinone', kind: 'complexIIQ', defaultZone: 'membrane' },
  { id: 'cytochrome-b6f', label: 'Cytochrome b6f', kind: 'complexIII', defaultZone: 'membrane' },
  { id: 'plastocyanin', label: 'Plastocyanin', kind: 'cytochromeC', defaultZone: 'top' },
  { id: 'photosystem-i', label: 'Photosystem I', kind: 'complexIV', defaultZone: 'membrane' },
  { id: 'light-psi', label: 'Light → PSI', kind: 'signal', defaultZone: 'top' },
  { id: 'nadph-output', label: 'NADP⁺ → NADPH', kind: 'oxygenWater', defaultZone: 'top' },
  { id: 'protons', label: 'High H⁺ (lumen)', kind: 'protons', defaultZone: 'top' },
  { id: 'low-protons', label: 'Low H⁺ (stroma)', kind: 'protons', defaultZone: 'bottom' },
  { id: 'atp-synthase', label: 'ATP synthase', kind: 'atpSynthase', defaultZone: 'membrane' },
  { id: 'adppi', label: 'ADP + Pi → ATP', kind: 'atpCycle', defaultZone: 'bottom' },
];

export const connectorOptions: Array<{ id: ConnectorType; label: string; short: string; color: string }> = [
  { id: 'electronFlow', label: 'Electron flow', short: 'e⁻', color: '#f0b323' },
  { id: 'protonFlow', label: 'Proton flow', short: 'H⁺', color: '#2e86de' },
  { id: 'transition', label: 'Light / output', short: '→', color: '#222222' },
];
