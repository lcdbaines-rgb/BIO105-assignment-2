import type { AssignmentAnchorMap } from '../types';

export const photosynthesisAnchors: AssignmentAnchorMap = {
  'light-psii': {
    transition: [{ name: 'transitionOut', x: 0.55, y: 0.82 }],
  },
  'water-oxygen': {
    transition: [{ name: 'transitionIn', x: 0.2, y: 0.58 }],
  },
  'photosystem-ii': {
    transition: [{ name: 'transitionIn', x: 0.45, y: 0.1 }],
    electronFlow: [{ name: 'electronOut', x: 0.88, y: 0.48 }],
  },
  plastoquinone: {
    electronFlow: [
      { name: 'electronIn', x: 0.18, y: 0.64 },
      { name: 'electronOut', x: 0.78, y: 0.44 },
    ],
  },
  'cytochrome-b6f': {
    electronFlow: [
      { name: 'electronIn', x: 0.08, y: 0.44 },
      { name: 'electronOut', x: 0.88, y: 0.48 },
    ],
    protonFlow: [{ name: 'protonOut', x: 0.5, y: 0.12 }],
  },
  plastocyanin: {
    electronFlow: [
      { name: 'electronIn', x: 0.2, y: 0.5 },
      { name: 'electronOut', x: 0.8, y: 0.5 },
    ],
  },
  'photosystem-i': {
    transition: [{ name: 'transitionIn', x: 0.45, y: 0.1 }],
    electronFlow: [
      { name: 'electronIn', x: 0.1, y: 0.56 },
      { name: 'electronOut', x: 0.84, y: 0.46 },
    ],
  },
  'light-psi': {
    transition: [{ name: 'transitionOut', x: 0.5, y: 0.82 }],
  },
  'nadph-output': {
    electronFlow: [{ name: 'electronIn', x: 0.16, y: 0.58 }],
  },
  protons: {
    protonFlow: [{ name: 'protonIn', x: 0.5, y: 0.78 }],
  },
  'low-protons': {
    protonFlow: [{ name: 'protonOut', x: 0.5, y: 0.22 }],
  },
  'atp-synthase': {
    protonFlow: [
      { name: 'protonIn', x: 0.5, y: 0.1 },
      { name: 'protonOut', x: 0.58, y: 0.9 },
    ],
    transition: [{ name: 'atpOut', x: 0.82, y: 0.78 }],
  },
  adppi: {
    transition: [{ name: 'transitionIn', x: 0.2, y: 0.36 }],
  },
};
