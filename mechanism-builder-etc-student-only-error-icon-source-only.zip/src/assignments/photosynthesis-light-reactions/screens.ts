import type { ScreenDef } from '../types';

export const photosynthesisScreens: ScreenDef[] = [
  {
    id: 'start',
    title: 'Screen 1 — Start',
    description: 'Build the light reactions of photosynthesis across the thylakoid membrane.',
    tasks: ['Read the goal and canvas instructions', 'Confirm your assigned version', 'Acknowledge AI use rules'],
    fields: [
      { key: 'version', label: 'Assigned version', type: 'select', options: ['Photosynthesis light reactions'] },
      { key: 'aiAck', label: 'I understand that AI use must be stated and I remain responsible for my answers.', type: 'checkbox' },
    ],
  },
  {
    id: 'light-reactions',
    title: 'Screen 2 — Build the Light Reactions',
    description: 'Place the major thylakoid membrane components and connect the light-driven electron pathway.',
    tasks: [
      'Place PSII, plastoquinone, cytochrome b6f, plastocyanin, and PSI in the correct positions',
      'Use electron arrows to move electrons from PSII through PSI to the NADPH output step',
      'Show water splitting at PSII and light input to both PSII and PSI',
      'Use Check your work, then revise until oxygen and NADPH are produced',
    ],
    fields: [
      { key: 'lightSummary', label: 'Explain how light excites electrons and how oxygen and NADPH are produced', type: 'textarea' },
    ],
  },
  {
    id: 'atp-branch',
    title: 'Screen 3 — Add ATP Synthase',
    description: 'Use the proton gradient across the thylakoid membrane to support ATP production.',
    tasks: [
      'Place high H⁺ in the lumen and low H⁺ in the stroma',
      'Show cytochrome b6f contributing to proton accumulation in the lumen',
      'Connect high H⁺ through ATP synthase back to low H⁺',
      'Place ADP + Pi → ATP near ATP synthase so ATP output is recognized',
    ],
    fields: [
      { key: 'atpSummary', label: 'Explain how the thylakoid proton gradient supports ATP production', type: 'textarea' },
    ],
  },
  {
    id: 'feedback',
    title: 'Screen 4 — App Feedback',
    description: 'Give feedback on how the app worked for you so the assignment shell can be improved.',
    tasks: ['Rate how easy the canvas was to use', 'Describe one thing that worked well', 'Describe one improvement that would help students'],
    fields: [
      { key: 'easeOfUse', label: 'How easy was the app to use?', type: 'select', options: ['Very easy', 'Mostly easy', 'Mixed', 'Mostly difficult', 'Very difficult'] },
      { key: 'workedWell', label: 'What worked well?', type: 'textarea' },
      { key: 'improveApp', label: 'What could be improved?', type: 'textarea' },
    ],
  },
];
