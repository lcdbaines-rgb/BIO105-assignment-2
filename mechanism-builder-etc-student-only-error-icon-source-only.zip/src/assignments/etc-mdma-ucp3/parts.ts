export { connectorOptions, mitochondriaParts as etcMdmaUcp3Parts } from '../etc-normal-system/parts';
