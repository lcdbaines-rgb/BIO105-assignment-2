import type { ScreenDef } from '../types';

export const etcMdmaUcp3Screens: ScreenDef[] = [
  {
    id: 'start',
    title: 'Screen 1 — Start',
    description: 'Build the normal ETC plus the MDMA-gated UCP3 proton leak branch.',
    tasks: ['Read the goal and canvas instructions', 'Confirm your assigned version', 'Acknowledge AI use rules'],
    fields: [
      { key: 'version', label: 'Assigned version', type: 'select', options: ['MDMA + UCP3 heat branch'] },
      { key: 'aiAck', label: 'I understand that AI use must be stated and I remain responsible for my answers.', type: 'checkbox' },
    ],
  },
  {
    id: 'normal',
    title: 'Screen 2 — Build the Normal System',
    description: 'First build the normal mitochondrial ETC and ATP synthase branch.',
    tasks: [
      'Place the normal ETC parts in the correct zones',
      'Connect electron flow from NADH and FADH2 to oxygen',
      'Connect proton pumping and ATP synthase so ATP production is supported',
      'Use Check your work, then revise until the normal system is functioning',
    ],
    fields: [
      { key: 'normalSummary', label: 'Describe how the normal ETC and proton gradient support ATP production', type: 'textarea' },
    ],
  },
  {
    id: 'heat-branch',
    title: 'Screen 3 — Add the MDMA / UCP3 Heat Branch',
    description: 'Add the MDMA signal and UCP3 leak so the proton gradient can be dissipated as heat.',
    tasks: [
      'Place UCP3 in the membrane and MDMA on the outer side of the membrane',
      'Connect high H⁺ to UCP3 and UCP3 back to low H⁺',
      'Connect MDMA to UCP3 using the output / signal arrow type',
      'Revise until the heat branch is recognized as functioning',
    ],
    fields: [
      { key: 'heatSummary', label: 'Explain how MDMA changes the pathway and why heat output increases', type: 'textarea' },
    ],
  },
  {
    id: 'feedback',
    title: 'Screen 4 — App Feedback',
    description: 'Give feedback on how the app worked for you so the assignment can be improved.',
    tasks: ['Rate how easy the canvas was to use', 'Describe one thing that worked well', 'Describe one improvement that would help students'],
    fields: [
      { key: 'easeOfUse', label: 'How easy was the app to use?', type: 'select', options: ['Very easy', 'Mostly easy', 'Mixed', 'Mostly difficult', 'Very difficult'] },
      { key: 'workedWell', label: 'What worked well?', type: 'textarea' },
      { key: 'improveApp', label: 'What could be improved?', type: 'textarea' },
    ],
  },
];
