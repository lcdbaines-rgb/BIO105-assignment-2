import type { PathwayTemplate } from '../types';
import { etcMdmaUcp3Anchors } from './anchors';
import { etcMdmaUcp3Parts, connectorOptions } from './parts';
import { buildEtcMdmaUcp3ExampleModel } from './presets';
import { etcMdmaUcp3Screens } from './screens';

export const etcMdmaUcp3Template: PathwayTemplate = {
  id: 'mitochondria-mdma-ucp3',
  name: 'Mitochondrial mechanism builder — MDMA/UCP3',
  subtitle: 'Heat-branch student version',
  layoutMode: 'membrane',
  canvasWidth: 1480,
  canvasHeight: 360,
  promptByScreen: {
    start: 'Read the directions and prepare to build both the normal ETC and the MDMA-gated UCP3 heat branch.',
    normal: 'Build the normal ETC and ATP synthase branch first.',
    'heat-branch': 'Add MDMA and UCP3 so the proton gradient can be dissipated as heat.',
    feedback: 'Complete the app feedback so the assignment shell can be improved before more versions are built.',
  },
  screens: etcMdmaUcp3Screens,
  parts: etcMdmaUcp3Parts,
  exampleAnswers: {
    version: 'MDMA + UCP3 heat branch',
    aiAck: true,
    normalSummary: 'Electrons move from NADH and FADH2 through the ETC to oxygen. Complexes I, III, and IV pump protons into the intermembrane space. Protons then return through ATP synthase to help drive ATP production.',
    heatSummary: 'MDMA activates the UCP3 branch, allowing protons to leak back across the membrane without passing through ATP synthase. That dissipates the gradient and releases more energy as heat.',
    easeOfUse: 'Mostly easy',
    workedWell: 'The staged screens made it easier to build the normal pathway first and then add the heat branch.',
    improveApp: 'It would help to highlight when the normal branch is correct before moving to the heat branch.',
  },
  connectorOptions,
  features: {
    futureStages: ['Screen 5 — UCP1 comparison (locked)', 'Screen 6 — Revision / explanation (locked)'],
    lockedPartIds: ['ucp1'],
    anchorSet: 'assignment',
    customAnchors: etcMdmaUcp3Anchors,
    exampleModelBuilder: buildEtcMdmaUcp3ExampleModel,
    checkerStyle: 'mitochondria',
    normalOnlyMode: false,
  },
};
