import type { Connector, PathwayTemplate, PlacedPart } from '../types';
import { getPartDimensions } from '../../data/model';

function placePart(template: PathwayTemplate, partId: string, x: number, y: number): PlacedPart {
  const part = template.parts.find((item) => item.id === partId);
  if (!part) throw new Error(`Missing part definition for ${partId}`);
  return {
    ...part,
    uid: `${partId}-${x}-${y}`,
    x,
    y,
    zone: part.defaultZone,
  };
}

function connector(from: PlacedPart, to: PlacedPart, type: Connector['type'], label: string, color: string, curveOffset = 0, fromAnchorName?: string, toAnchorName?: string): Connector {
  return {
    id: `${type}-${from.uid}-${to.uid}`,
    from: from.uid,
    to: to.uid,
    type,
    label,
    color,
    curveOffset,
    fromAnchorName,
    toAnchorName,
  };
}

export function buildEtcMdmaUcp3ExampleModel(template: PathwayTemplate) {
  const nadh = placePart(template, 'nadh', 110, 244);
  const fadh2 = placePart(template, 'fadh2', 278, 244);
  const complexI = placePart(template, 'complex-i', 246, 110);
  const complexIIQ = placePart(template, 'complex-ii-q', 478, 110);
  const complexIII = placePart(template, 'complex-iii', 704, 110);
  const cytoC = placePart(template, 'cytochrome-c', 808, 48);
  const complexIV = placePart(template, 'complex-iv', 988, 110);
  const oxygenWater = placePart(template, 'oxygen-water', 1132, 42);
  const protons = placePart(template, 'protons', 878, 22);
  const lowProtons = placePart(template, 'low-protons', 980, 262);
  const atpSynthase = placePart(template, 'atp-synthase', 1232, 112);
  const adpPi = placePart(template, 'adppi', 1260, 252);
  const ucp3 = placePart(template, 'ucp3', 1094, 110);
  const mdma = placePart(template, 'mdma', 1098, 18);
  const heat = placePart(template, 'heat', 1372, 76);

  const placedParts = [nadh, fadh2, complexI, complexIIQ, complexIII, cytoC, complexIV, oxygenWater, protons, lowProtons, atpSynthase, adpPi, ucp3, mdma, heat];

  const electron = '#f0b323';
  const proton = '#2e86de';
  const transition = '#222222';

  const connectors: Connector[] = [
    connector(nadh, complexI, 'electronFlow', 'NADH → Complex I', electron),
    connector(fadh2, complexIIQ, 'electronFlow', 'FADH2 → Complex II + Q', electron),
    connector(complexI, complexIIQ, 'electronFlow', 'Complex I → Complex II + Q', electron, -20),
    connector(complexIIQ, complexIII, 'electronFlow', 'Complex II + Q → Complex III', electron),
    connector(complexIII, cytoC, 'electronFlow', 'Complex III → cytochrome c', electron, -30),
    connector(cytoC, complexIV, 'electronFlow', 'cytochrome c → Complex IV', electron, -20),
    connector(complexIV, oxygenWater, 'electronFlow', 'Complex IV → O₂ → H₂O', electron),
    connector(lowProtons, complexI, 'protonFlow', 'Low H⁺ → Complex I', proton),
    connector(complexI, protons, 'protonFlow', 'Complex I → High H⁺', proton),
    connector(lowProtons, complexIII, 'protonFlow', 'Low H⁺ → Complex III', proton),
    connector(complexIII, protons, 'protonFlow', 'Complex III → High H⁺', proton),
    connector(lowProtons, complexIV, 'protonFlow', 'Low H⁺ → Complex IV', proton),
    connector(complexIV, protons, 'protonFlow', 'Complex IV → High H⁺', proton),
    connector(protons, atpSynthase, 'protonFlow', 'High H⁺ → ATP synthase', proton),
    connector(atpSynthase, lowProtons, 'protonFlow', 'ATP synthase → Low H⁺', proton),
    connector(atpSynthase, adpPi, 'transition', 'ATP synthase → ADP + Pi → ATP', transition),
    connector(protons, ucp3, 'protonFlow', 'High H⁺ → UCP3', proton),
    connector(ucp3, lowProtons, 'protonFlow', 'UCP3 → Low H⁺', proton),
    connector(mdma, ucp3, 'transition', 'MDMA → UCP3', transition),
  ];

  return { placedParts, connectors };
}
