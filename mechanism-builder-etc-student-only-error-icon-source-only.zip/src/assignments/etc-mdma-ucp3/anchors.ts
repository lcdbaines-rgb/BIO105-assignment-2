export { etcNormalSystemAnchors as etcMdmaUcp3Anchors } from '../etc-normal-system/anchors';
