import type { PathwayRuleSchema } from '../types';
import { etcNormalSystemSchema } from '../etc-normal-system/rules';

export const etcMdmaUcp3Schema: PathwayRuleSchema = {
  ...etcNormalSystemSchema,
  templateId: 'mitochondria-mdma-ucp3',
};
