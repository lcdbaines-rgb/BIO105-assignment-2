# Mechanism Builder App

Clean Vite + React + TypeScript package for the mitochondrial ETC mechanism builder.

## Included
- Modular React app
- Move / Connect modes
- Electron flow constrained through Coenzyme Q
- Free-form H+ flow arrows
- Drag-and-drop parts
- Live connection preview line
- Animated arrow dots
- Screen-by-screen student workflow

## Run
```bash
npm install
npm run dev
```

## Files
- `src/App.tsx` — main app shell
- `src/components/ModelCanvas.tsx` — interactive canvas
- `src/components/PartGraphic.tsx` — biology part shapes
- `src/components/UI.tsx` — shared UI helpers
- `src/components/Field.tsx` — form field renderer
- `src/data/model.ts` — types, screens, parts, connector options
- `src/lib/utils.ts` — helpers
